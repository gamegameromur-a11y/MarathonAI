namespace MarathonAI.Core.Api;

/// <summary>
/// Groq Chat Completions API'sine bağlanan istemci (Mod 1 — Resmi API).
///
/// Groq, açık kaynak modelleri (Llama, Qwen, GPT-OSS vb.) özel LPU
/// donanımında çok hızlı çalıştıran bir sağlayıcı; cömert bir ücretsiz
/// tier'ı var (2026 itibarıyla dakikada ~30 istek / ~6000 token, modele
/// göre değişir). Kullanıcının kendi API anahtarı olmasa bile Groq
/// üzerinden ücretsiz olarak MarathonAI'yi deneyebilmesi hedefleniyor
/// (bkz. docs/MarathonAI_Plan.md, Bölüm 1 — "herkesin API'ye verecek
/// parası olmayabilir" problemi).
///
/// API formatı OpenAI ile uyumlu olduğu için OpenAiCompatibleChatClient
/// üzerinden, sadece URL ve varsayılan model farklı verilerek inşa edildi.
/// </summary>
public sealed class GroqChatClient : OpenAiCompatibleChatClient
{
    private const string ApiUrl = "https://api.groq.com/openai/v1/chat/completions";

    // llama-3.3-70b-versatile: Groq'un ücretsiz tier'ında yaygın kullanılan,
    // hız/kalite dengesi iyi bir model. İleride model seçimi ayarlar
    // sisteminden kullanıcıya bırakılacak.
    private const string DefaultModel = "llama-3.3-70b-versatile";

    public GroqChatClient(string apiKey, string model = DefaultModel, System.Net.Http.HttpClient? httpClient = null)
        : base("Groq", ApiUrl, apiKey, model, httpClient)
    {
    }
}
