using System;
using System.IO;

namespace MarathonAI.Core.Settings;

/// <summary>
/// Dosya sistemi erişim kontrollerini merkezi olarak uygular (bkz.
/// docs/MarathonAI_Plan.md, Bölüm 6.3 — "model kendi kendini sınırlar"
/// varsayımına güvenilmeyeceği, MarathonAI'nin kendi teknik izin/sandbox
/// katmanını kuracağı prensibi).
///
/// ÖNEMLİ: Bu sınıf şu an sadece TEMEL POLİTİKA sorgusu sağlıyor
/// (IsPathAllowed). Henüz hiçbir agent/araç bu kontrolcüyü çağıran bir
/// gerçek dosya işlemi yapmıyor — Mod 1/3'teki Araç Kütüphanesi (Bölüm
/// 6.6) inşa edildiğinde, her dosya okuma/yazma/silme işlemi bu sınıfın
/// IsPathAllowed metodundan GEÇMEK ZORUNDA olacak, aksi halde işlem
/// reddedilecek.
/// </summary>
public static class FileSystemGuard
{
    /// <summary>
    /// Genel erişim anahtarı kapalıysa hiçbir yola izin verilmez.
    /// Açıksa, BlockedFolders listesindeki (ve onların alt klasörlerindeki)
    /// yollar yine de reddedilir — bu, kullanıcının "genel olarak izin
    /// veriyorum ama şu klasörlere asla girme" tercihini karşılar.
    /// </summary>
    public static bool IsPathAllowed(string fullPath)
    {
        var settings = SettingsManager.Load();

        if (!settings.FileSystemAccessEnabled)
        {
            return false;
        }

        var normalizedTarget = NormalizePath(fullPath);

        foreach (var blockedFolder in settings.BlockedFolders)
        {
            var normalizedBlocked = NormalizePath(blockedFolder);

            // Hedef yol, yasaklı klasörün kendisi VEYA bir alt yolu ise
            // reddedilir — sadece tam eşleşme değil, tüm alt ağaç
            // korunur (örn. "C:\Users\Ali\Belgeler" yasaklıysa
            // "C:\Users\Ali\Belgeler\gizli.txt" da yasaktır).
            if (normalizedTarget.Equals(normalizedBlocked, StringComparison.OrdinalIgnoreCase) ||
                normalizedTarget.StartsWith(normalizedBlocked + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }
        }

        return true;
    }

    private static string NormalizePath(string path)
    {
        // Sondaki "\" işaretlerini kaldırıp tutarlı bir karşılaştırma
        // sağlar (örn. "C:\Foo\" ile "C:\Foo" aynı klasör sayılmalı).
        return Path.GetFullPath(path).TrimEnd(Path.DirectorySeparatorChar);
    }
}
