using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using MarathonAI.Core.Api;
using MarathonAI.Core.Localization;
using MarathonAI.UI;

namespace MarathonAI;

/// <summary>
/// Ana pencere. Sekme sistemi + tam konuşma geçmişi desteği. Her sekme
/// (ChatTab) kendi sohbet geçmişini ve kendi seçili sağlayıcısını taşır;
/// her yeni mesajda TÜM geçmiş API'ye gönderilir, böylece model önceki
/// mesajları "hatırlayarak" cevap verir. Sekme içinde sağlayıcı
/// değiştirildiğinde de aynı geçmiş yeni sağlayıcıya aktarılır
/// (bkz. docs/MarathonAI_Plan.md, Bölüm 4 ve 9).
/// </summary>
public partial class MainWindow : Window
{
    /// <summary>
    /// XAML tarafında ComboBox'ların ItemsSource'u olarak kullanılıyor
    /// (RelativeSource ile Window'a erişip buradan okunuyor).
    /// </summary>
    public IReadOnlyList<ProviderInfo> AvailableProviders => ProviderRegistry.All;

    public ObservableCollection<ChatTab> Tabs { get; } = new();

    public MainWindow()
    {
        InitializeComponent();

        ChatTabControl.ItemsSource = Tabs;

        // Uygulama açıldığında bir adet başlangıç sekmesi oluşturulur.
        AddNewTab();
    }

    private void SettingsButton_Click(object sender, RoutedEventArgs e)
    {
        var settingsWindow = new SettingsWindow
        {
            Owner = this
        };
        settingsWindow.ShowDialog();
    }

    private void NewTabButton_Click(object sender, RoutedEventArgs e)
    {
        AddNewTab();
    }

    private void AddNewTab()
    {
        var loc = LocalizationManager.Instance;
        var tab = new ChatTab(ProviderRegistry.Default, title: $"{loc.T("TabTitlePrefix")} {Tabs.Count + 1}");
        tab.ClientCreationFailed += message =>
        {
            tab.Messages.Add(new ChatMessage(MessageRole.Warning, message));
        };

        Tabs.Add(tab);
        ChatTabControl.SelectedItem = tab;
    }

    private void InputTextBox_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key != Key.Enter)
        {
            return;
        }

        e.Handled = true;

        if (sender is TextBox { DataContext: ChatTab tab } textBox)
        {
            _ = SendMessageAsync(tab, textBox);
        }
    }

    private void SendButton_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button { DataContext: ChatTab tab } button)
        {
            return;
        }

        // Button ile aynı satırdaki TextBox'ı, ikisinin ortak ebeveyni
        // (Grid) üzerinden buluyoruz. DataContext her ikisinde de aynı
        // ChatTab olduğu için bu, doğru sekmenin doğru input kutusunu
        // garanti eder.
        if (System.Windows.Media.VisualTreeHelper.GetParent(button) is Grid grid)
        {
            foreach (var child in grid.Children)
            {
                if (child is TextBox textBox)
                {
                    _ = SendMessageAsync(tab, textBox);
                    return;
                }
            }
        }
    }

    private async Task SendMessageAsync(ChatTab tab, TextBox inputTextBox)
    {
        var text = inputTextBox.Text?.Trim();
        if (string.IsNullOrEmpty(text))
        {
            return;
        }

        if (tab.ChatClient is null)
        {
            tab.Messages.Add(new ChatMessage(
                MessageRole.Warning,
                LocalizationManager.Instance.T("MissingApiKeyWarning")));
            return;
        }

        inputTextBox.Clear();
        inputTextBox.IsEnabled = false;

        tab.Messages.Add(new ChatMessage(MessageRole.User, text));

        try
        {
            // Sekmenin tüm görünür geçmişinden (User/Assistant rolleriyle
            // işaretli olanlar) API'nin anlayacağı user/assistant formatına
            // dönüştürülüyor. Warning/Error/System gibi mesajlar asıl
            // konuşmanın parçası değil, bu yüzden API'ye gönderilmiyor —
            // aksi halde model kendi hata mesajlarını "konuşmanın bir
            // parçasıymış" gibi yorumlayabilirdi. Bu karşılaştırma
            // MessageRole enum'ına göre yapıldığı için dil değişse bile
            // (görüntülenen etiketler farklı olsa bile) hep doğru çalışır.
            var conversationHistory = tab.Messages
                .Where(m => m.Role is MessageRole.User or MessageRole.Assistant)
                .Select(m => m.Role == MessageRole.User
                    ? ApiChatMessage.User(m.Content)
                    : ApiChatMessage.Assistant(m.Content))
                .ToList();

            // Boş bir Assistant mesajı ekleyip, gelen her parçayı bu
            // mesajın Content'ine ekliyoruz — ChatMessage artık
            // INotifyPropertyChanged uyguladığı için (bkz. UI/ChatMessage.cs)
            // her ekleme UI'da anında görünür, kullanıcı cevabın "akarak"
            // oluştuğunu görür.
            var responseMessage = new ChatMessage(MessageRole.Assistant, string.Empty);
            tab.Messages.Add(responseMessage);

            await foreach (var chunk in tab.ChatClient.StreamMessageAsync(conversationHistory))
            {
                responseMessage.Content += chunk;
            }
        }
        catch (Exception ex)
        {
            // İlk iskelette basit hata gösterimi. İleride kullanıcıya
            // daha temiz bir hata/bildirim sistemi ile sunulacak.
            tab.Messages.Add(new ChatMessage(MessageRole.Error, ex.Message));
        }
        finally
        {
            inputTextBox.IsEnabled = true;
            inputTextBox.Focus();
        }
    }
}
