using MarathonAI.Core.Tools;

namespace MarathonAI.Core.Api;

/// <summary>
/// Tüm Mod 1 (Resmi API) sağlayıcılarının uyacağı ortak arayüz.
/// OpenAI, Claude, Gemini, Mistral vb. her biri bu arayüzü kendi
/// implementasyonuyla karşılar — böylece MainWindow (ve sekme/model
/// seçim sistemi) hangi sağlayıcıyla konuştuğunu bilmek zorunda kalmaz,
/// sadece IChatClient ile çalışır.
///
/// StreamMessageAsync, cevabı parça parça (token/chunk) döndürür —
/// kullanıcı arayüzde cevabın "akarak" oluştuğunu görür (bkz.
/// docs/MarathonAI_Plan.md, Bölüm 1 — "hız" marka değeri). Tüm konuşma
/// geçmişini (conversationHistory) kabul eder, tek bir mesaj değil —
/// böylece model önceki mesajları "hatırlayarak" cevap verir.
///
/// SendMessageWithToolsAsync, Bölüm 6.6'daki Araç Kütüphanesi ile
/// çalışır — model bir aracı çağırmak isterse ToolCallRequest listesi
/// döner (metin cevabı yerine/yanında); MarathonAI aracı çalıştırıp
/// ToolCallResult'ı tekrar modele göndermekten sorumludur (bu döngü
/// Core/Api/ToolCallingLoop.cs'de yönetilir). Bu akış streaming
/// DESTEKLEMEZ — tool-calling turu tamamlanana kadar tek seferde cevap
/// bekler; kullanıcıya gösterilecek NİHAİ metin cevabı geldiğinde
/// StreamMessageAsync'e benzer şekilde akıtılabilir (bkz.
/// ToolCallingLoop).
///
/// İleride bu arayüze şunlar eklenecek:
///   - System prompt / reasoning effort parametreleri (Bölüm 4)
/// </summary>
public interface IChatClient
{
    IAsyncEnumerable<string> StreamMessageAsync(
        IReadOnlyList<ApiChatMessage> conversationHistory,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Tool-calling destekleyen tek seferlik istek. Model ya bir metin
    /// cevabı (TextResponse dolu, ToolCalls boş) ya da bir/birden fazla
    /// araç çağrısı isteği (ToolCalls dolu) döndürür.
    /// </summary>
    Task<ChatCompletionResult> SendMessageWithToolsAsync(
        IReadOnlyList<ApiChatMessage> conversationHistory,
        IReadOnlyList<ToolDefinition> availableTools,
        CancellationToken cancellationToken = default);
}

/// <summary>
/// Tool-calling destekli bir isteğin sonucu. Ya TextResponse doludur
/// (model normal bir cevap verdi) ya da ToolCalls doludur (model bir
/// veya daha fazla araç çağırmak istiyor) — ikisi birden dolu olmaz.
/// </summary>
public sealed record ChatCompletionResult(
    string? TextResponse,
    IReadOnlyList<ToolCallRequest> ToolCalls);
