using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using MarathonAI.Core.Api;
using MarathonAI.Core.Localization;

namespace MarathonAI.UI;

/// <summary>
/// Tek bir sohbet sekmesinin durumunu tutar: başlığı, kendi mesaj
/// geçmişi, o sekmede seçili olan sağlayıcı. Her sekme birbirinden
/// bağımsızdır — bir sekmede Groq ile konuşulurken başka bir sekmede
/// aynı anda OpenAI ile konuşulabilir (bkz. docs/MarathonAI_Plan.md,
/// Bölüm 4 — "sohbet içinde model değiştirme" ve genel çoklu-model
/// vizyonu).
///
/// INotifyPropertyChanged uygulanıyor ki sekme başlığı gibi alanlar
/// değiştiğinde arayüz (TabControl) otomatik güncellensin.
/// </summary>
public sealed class ChatTab : INotifyPropertyChanged
{
    private string _title;
    private ProviderInfo _selectedProvider;
    private IChatClient? _chatClient;

    public ObservableCollection<ChatMessage> Messages { get; } = new();

    public string Title
    {
        get => _title;
        set => SetField(ref _title, value);
    }

    public ProviderInfo SelectedProvider
    {
        get => _selectedProvider;
        set
        {
            var previousProvider = _selectedProvider;
            if (SetField(ref _selectedProvider, value))
            {
                RebuildChatClient();

                // Constructor, field'a doğrudan atama yaptığı için (bu
                // setter'ı çağırmaz), buraya her zaman gerçek bir
                // kullanıcı değişikliğiyle gelinir — kullanıcı hangi
                // sağlayıcıya geçtiğini sohbet akışında görsün
                // (bkz. docs/MarathonAI_Plan.md, Bölüm 4).
                var messageTemplate = LocalizationManager.Instance.T("ProviderChangedMessage");
                Messages.Add(new ChatMessage(
                    MessageRole.System,
                    string.Format(messageTemplate, previousProvider.DisplayName, value.DisplayName)));
            }
        }
    }

    public IChatClient? ChatClient => _chatClient;

    /// <summary>
    /// Sağlayıcı değiştirildiğinde veya sekme ilk oluşturulduğunda
    /// hatayı (örn. eksik API anahtarı) bu koleksiyona bir sistem
    /// mesajı olarak ekler ki UI'da görünsün.
    /// </summary>
    public event Action<string>? ClientCreationFailed;

    public ChatTab(ProviderInfo initialProvider, string? title = null)
    {
        _selectedProvider = initialProvider;
        _title = title ?? initialProvider.DisplayName;
        RebuildChatClient();
    }

    private void RebuildChatClient()
    {
        try
        {
            _chatClient = SelectedProvider.CreateClient();
        }
        catch (InvalidOperationException ex)
        {
            _chatClient = null;
            ClientCreationFailed?.Invoke(ex.Message);
        }
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    private bool SetField<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value))
        {
            return false;
        }

        field = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        return true;
    }
}
