using System.IO;
using System.Text.Json;
using MarathonAI.Core.Settings;

namespace MarathonAI.Core.Tools;

/// <summary>
/// Modelin, kullanıcının izin verdiği bir dosyayı okumasını sağlayan
/// araç. Bu, MarathonAI Araç Kütüphanesi'nin (Bölüm 6.6) ilk somut
/// implementasyonu ve FileSystemGuard'ın (Bölüm 6.3 — "model kendi
/// kendini sınırlar" varsayımına güvenilmeyeceği prensibi) GERÇEKTEN
/// kullanıldığı ilk yer.
///
/// Akış: model "read_file" aracını çağırmak istiyor → biz ÖNCE
/// FileSystemGuard.IsPathAllowed ile kontrol ediyoruz → izin yoksa
/// modele "erişim reddedildi" sonucu dönüyoruz (dosyayı hiç açmadan) →
/// izin varsa dosyayı okuyup içeriği modele veriyoruz.
/// </summary>
public sealed class ReadFileTool : IToolHandler
{
    public ToolDefinition Definition { get; } = new(
        Name: "read_file",
        Description: "Kullanıcının bilgisayarında, izin verilen bir konumdaki bir metin dosyasının içeriğini okur.",
        ParametersJsonSchema: """
        {
          "type": "object",
          "properties": {
            "path": {
              "type": "string",
              "description": "Okunacak dosyanın tam yolu (örn. C:\\Users\\Ali\\Belgeler\\not.txt)"
            }
          },
          "required": ["path"]
        }
        """);

    public Task<string> ExecuteAsync(string argumentsJson, CancellationToken cancellationToken = default)
    {
        string? path;
        try
        {
            using var doc = JsonDocument.Parse(argumentsJson);
            path = doc.RootElement.GetProperty("path").GetString();
        }
        catch (Exception)
        {
            return Task.FromResult(BuildErrorResult("Geçersiz araç parametresi (path okunamadı)."));
        }

        if (string.IsNullOrWhiteSpace(path))
        {
            return Task.FromResult(BuildErrorResult("Dosya yolu boş olamaz."));
        }

        // KRİTİK GÜVENLİK ADIMI: dosya diske hiç dokunulmadan önce
        // FileSystemGuard'a soruluyor. Bu, Bölüm 6.3'teki prensibin
        // (modelin kendi "iyi niyetine" değil, sistemin teknik
        // kısıtlamasına güvenilmesi) somut uygulaması — model "bu
        // dosyayı okumak istemiyorum, zararlı" demiyor, sistem onun
        // yerine karar veriyor.
        if (!FileSystemGuard.IsPathAllowed(path))
        {
            return Task.FromResult(BuildErrorResult(
                "Erişim reddedildi: Bu yol, kullanıcının dosya sistemi erişim ayarlarına göre yasaklı " +
                "veya genel dosya erişimi kapalı. Kullanıcıya, Ayarlar > Dosya Sistemi Erişimi bölümünden " +
                "bu klasöre erişim izni vermesi gerektiğini söyle."));
        }

        try
        {
            if (!File.Exists(path))
            {
                return Task.FromResult(BuildErrorResult($"Dosya bulunamadı: {path}"));
            }

            var content = File.ReadAllText(path);

            // Aşırı büyük dosyaların tüm konuşma bağlamını (context) işgal
            // etmesini önlemek için makul bir üst sınır konuyor. İleride
            // bu sınır ayarlanabilir hale getirilebilir.
            const int maxLength = 20_000;
            if (content.Length > maxLength)
            {
                content = content[..maxLength] + "\n\n[... dosya bu noktada kırpıldı, çok uzun ...]";
            }

            return Task.FromResult(JsonSerializer.Serialize(new { success = true, content }));
        }
        catch (Exception ex)
        {
            return Task.FromResult(BuildErrorResult($"Dosya okunurken hata oluştu: {ex.Message}"));
        }
    }

    private static string BuildErrorResult(string message) =>
        JsonSerializer.Serialize(new { success = false, error = message });
}
