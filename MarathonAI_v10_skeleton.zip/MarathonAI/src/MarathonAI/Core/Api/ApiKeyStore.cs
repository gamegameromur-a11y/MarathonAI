using MarathonAI.Core.Settings;

namespace MarathonAI.Core.Api;

/// <summary>
/// API anahtarlarını okuyan yardımcı sınıf. Öncelik sırası:
///   1. Ayarlar dosyasında (SettingsManager, %AppData%\MarathonAI) kayıtlı
///      anahtar — kullanıcının ayarlar panelinden girdiği asıl yol.
///      Diskte SecureStore (Windows DPAPI) ile şifrelenmiş halde durur,
///      burada okunurken çözülür.
///   2. Ortam değişkeni (MARATHONAI_GROQ_KEY / MARATHONAI_OPENAI_KEY) —
///      geliştirme/test sırasında hızlı deneme için bir "fallback"
///      (şifrelenmez, zaten ortam değişkenleri farklı bir güvenlik
///      modeline tabidir).
///
/// Bölüm 7 (Gizlilik) gereği anahtarlar hiçbir zaman koda sabit
/// yazılmaz veya bir sunucuya gönderilmez; sadece kullanıcının kendi
/// bilgisayarında, kendi Windows hesabıyla korunmuş şekilde kalır.
/// </summary>
public static class ApiKeyStore
{
    public static string GetOpenAiKey() => GetKey(providerId: "openai", envVarName: "MARATHONAI_OPENAI_KEY");

    public static string GetGroqKey() => GetKey(providerId: "groq", envVarName: "MARATHONAI_GROQ_KEY");

    /// <summary>
    /// Genel amaçlı okuma — Ayarlar penceresi gibi, sağlayıcı Id'sini
    /// ProviderRegistry üzerinden dinamik olarak alan yerler için.
    /// GetOpenAiKey/GetGroqKey ile aynı mantığı çalıştırır, sadece ortam
    /// değişkeni adını sağlayıcıya göre otomatik türetir.
    /// </summary>
    public static string GetKeyByProviderId(string providerId)
    {
        var envVarName = $"MARATHONAI_{providerId.ToUpperInvariant()}_KEY";
        return GetKey(providerId, envVarName);
    }

    private static string GetKey(string providerId, string envVarName)
    {
        var settings = SettingsManager.Load();
        if (settings.ApiKeys.TryGetValue(providerId, out var encryptedKey) && !string.IsNullOrWhiteSpace(encryptedKey))
        {
            var decrypted = SecureStore.Decrypt(encryptedKey);
            if (!string.IsNullOrEmpty(decrypted))
            {
                return decrypted;
            }
        }

        return Environment.GetEnvironmentVariable(envVarName) ?? string.Empty;
    }

    public static void SetKey(string providerId, string apiKey)
    {
        var settings = SettingsManager.Load();
        settings.ApiKeys[providerId] = SecureStore.Encrypt(apiKey);
        SettingsManager.Save(settings);
    }
}
