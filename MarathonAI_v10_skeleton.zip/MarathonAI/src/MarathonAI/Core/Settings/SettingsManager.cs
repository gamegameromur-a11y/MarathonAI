using System.IO;
using System.Text.Json;

namespace MarathonAI.Core.Settings;

/// <summary>
/// AppSettings'i kullanıcının kendi bilgisayarında (%AppData%\MarathonAI\
/// settings.json) saklayıp yükler. Bölüm 7 gereği bu dosya asla bir
/// sunucuya gönderilmez, sadece local diskte kalır.
///
/// GÜVENLİK: API anahtarları, bu dosyaya yazılmadan önce SecureStore
/// (Windows DPAPI) ile şifrelenir (bkz. Core/Api/ApiKeyStore.cs) — yani
/// settings.json dosyasının içeriği base64 şifreli metin olarak durur,
/// düz metin API anahtarı içermez. Diğer alanlar (tema gibi) hassas
/// olmadığı için düz metin kalır.
/// </summary>
public static class SettingsManager
{
    private static readonly string SettingsDirectory = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "MarathonAI");

    private static readonly string SettingsFilePath = Path.Combine(SettingsDirectory, "settings.json");

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true
    };

    public static AppSettings Load()
    {
        try
        {
            if (!File.Exists(SettingsFilePath))
            {
                return new AppSettings();
            }

            var json = File.ReadAllText(SettingsFilePath);
            return JsonSerializer.Deserialize<AppSettings>(json, JsonOptions) ?? new AppSettings();
        }
        catch (Exception)
        {
            // Ayar dosyası bozuksa/okunamıyorsa uygulamanın açılmasını
            // engellememek için boş bir ayar seti ile devam edilir.
            // İleride bu durum kullanıcıya bir bildirimle iletilebilir.
            return new AppSettings();
        }
    }

    public static void Save(AppSettings settings)
    {
        Directory.CreateDirectory(SettingsDirectory);
        var json = JsonSerializer.Serialize(settings, JsonOptions);
        File.WriteAllText(SettingsFilePath, json);
    }
}
