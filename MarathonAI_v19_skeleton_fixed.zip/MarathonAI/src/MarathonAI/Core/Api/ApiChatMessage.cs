using MarathonAI.Core.Tools;

namespace MarathonAI.Core.Api;

/// <summary>
/// API isteğine gönderilecek tek bir konuşma turu. UI katmanındaki
/// MarathonAI.UI.ChatMessage'dan (Role artık dilden bağımsız bir enum:
/// MessageRole — bkz. UI/ChatMessage.cs) kasıtlı olarak ayrı tutuluyor —
/// burada Role API'nin beklediği sabit değerlerden biri olmalı: "user",
/// "assistant" veya "tool" (bkz. docs/MarathonAI_Plan.md Bölüm 6.6 —
/// MarathonAI Araç Kütüphanesi).
///
/// ToolCalls ve ToolCallId, sadece tool-calling akışında kullanılır
/// (bkz. Core/Api/ToolCallingLoop.cs):
///   - Model bir araç çağırmak istediğinde, bu isteği temsil eden
///     "assistant" mesajı ToolCalls alanını doldurur (Content boş
///     kalabilir).
///   - Aracın çalıştırılma sonucu, "tool" rolündeki bir mesaj olarak
///     geri gönderilir; bu mesaj hangi çağrıya cevap verdiğini
///     belirtmek için ToolCallId taşır.
/// </summary>
public sealed record ApiChatMessage(
    string Role,
    string Content,
    IReadOnlyList<ToolCallRequest>? ToolCalls = null,
    string? ToolCallId = null)
{
    public static ApiChatMessage User(string content) => new("user", content);
    public static ApiChatMessage Assistant(string content) => new("assistant", content);

    public static ApiChatMessage AssistantWithToolCalls(IReadOnlyList<ToolCallRequest> toolCalls) =>
        new("assistant", string.Empty, ToolCalls: toolCalls);

    public static ApiChatMessage ToolResult(string toolCallId, string resultJson) =>
        new("tool", resultJson, ToolCallId: toolCallId);
}
