using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using MarathonAI.Core.Api;
using MarathonAI.Core.Localization;
using MarathonAI.Core.Tools;
using MarathonAI.UI;

namespace MarathonAI;

/// <summary>
/// Ana pencere. Sekme sistemi + tam konuşma geçmişi desteği. Her sekme
/// (ChatTab) kendi sohbet geçmişini ve kendi seçili sağlayıcısını taşır;
/// her yeni mesajda TÜM geçmiş API'ye gönderilir, böylece model önceki
/// mesajları "hatırlayarak" cevap verir. Sekme içinde sağlayıcı
/// değiştirildiğinde de aynı geçmiş yeni sağlayıcıya aktarılır
/// (bkz. docs/MarathonAI_Plan.md, Bölüm 4 ve 9).
/// </summary>
public partial class MainWindow : Window
{
    /// <summary>
    /// XAML tarafında ComboBox'ların ItemsSource'u olarak kullanılıyor
    /// (RelativeSource ile Window'a erişip buradan okunuyor).
    /// </summary>
    public IReadOnlyList<ProviderInfo> AvailableProviders => ProviderRegistry.All;

    public ObservableCollection<ChatTab> Tabs { get; } = new();

    public MainWindow()
    {
        InitializeComponent();

        ChatTabControl.ItemsSource = Tabs;
        ChatTabControl.SelectionChanged += (_, _) => UpdateSelectedTabFlags();

        // Uygulama açıldığında bir adet başlangıç sekmesi oluşturulur.
        AddNewTab();
    }

    /// <summary>
    /// Tabs listesindeki her ChatTab'ın IsSelectedTab bayrağını, gerçek
    /// TabControl.SelectedItem ile senkron tutar — sidebar'daki aktif
    /// sekme vurgusu bu bayrağa bağlı (bkz. UI/ChatTab.cs, IsSelectedTab).
    /// </summary>
    private void UpdateSelectedTabFlags()
    {
        foreach (var tab in Tabs)
        {
            tab.IsSelectedTab = ReferenceEquals(tab, ChatTabControl.SelectedItem);
        }
    }

    private void SettingsButton_Click(object sender, RoutedEventArgs e)
    {
        var settingsWindow = new SettingsWindow
        {
            Owner = this
        };
        settingsWindow.ShowDialog();
    }

    private void NewTabButton_Click(object sender, RoutedEventArgs e)
    {
        AddNewTab();
    }

    /// <summary>
    /// Sidebar'daki "Önceki sohbetler" listesindeki bir öğeye
    /// tıklandığında o sekmeye geçer. Sidebar öğeleri doğrudan Tabs
    /// koleksiyonundan (ItemsControl binding'i ile) türetiliyor —
    /// prototipteki sahte veri yerine gerçek sekme listesi kullanılıyor
    /// (bkz. marathonai-ui-prototype.html referansı).
    /// </summary>
    private void SidebarHistoryItem_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button { DataContext: ChatTab tab })
        {
            ChatTabControl.SelectedItem = tab;
        }
    }

    /// <summary>
    /// Sekme başlığındaki "×" butonuna tıklandığında o sekmeyi kapatır.
    /// En az 1 sekme her zaman açık kalmalı — son sekmeyi kapatma
    /// denemesi görmezden gelinir (bkz. marathonai-ui-prototype.html
    /// referansı, her sekmede bir kapatma × işareti var).
    /// </summary>
    private void CloseTabButton_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button { DataContext: ChatTab tabToClose })
        {
            return;
        }

        if (Tabs.Count <= 1)
        {
            return;
        }

        var wasSelected = ChatTabControl.SelectedItem == tabToClose;
        var closingIndex = Tabs.IndexOf(tabToClose);

        Tabs.Remove(tabToClose);

        if (wasSelected)
        {
            // Kapatılan sekme seçiliyse, ondan bir önceki (ya da artık
            // ilk sekme neyse) sekmeye geç — kullanıcı boş bir sekme
            // görmesin.
            var newIndex = Math.Max(0, closingIndex - 1);
            ChatTabControl.SelectedItem = Tabs[Math.Min(newIndex, Tabs.Count - 1)];
        }
    }

    private void AddNewTab()
    {
        var loc = LocalizationManager.Instance;
        var tab = new ChatTab(ProviderRegistry.Default, title: $"{loc.T("TabTitlePrefix")} {Tabs.Count + 1}");
        tab.ClientCreationFailed += message =>
        {
            tab.Messages.Add(new ChatMessage(MessageRole.Warning, message));
        };

        Tabs.Add(tab);
        ChatTabControl.SelectedItem = tab;
    }

    private void InputTextBox_KeyDown(object sender, KeyEventArgs e)
    {
        // Shift+Enter: yeni satır (varsayılan TextBox davranışına izin
        // ver, e.Handled=false bırak). Sadece Enter: mesajı gönder.
        // (bkz. marathonai-ui-prototype.html — "ENTER ile gönder,
        // SHIFT+ENTER ile yeni satır" ipucu)
        if (e.Key != Key.Enter || Keyboard.Modifiers == ModifierKeys.Shift)
        {
            return;
        }

        e.Handled = true;

        if (sender is TextBox { DataContext: ChatTab tab } textBox)
        {
            _ = SendMessageAsync(tab, textBox);
        }
    }

    private void SendButton_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button { DataContext: ChatTab tab } button)
        {
            return;
        }

        var textBox = FindMessageInputBox(button);
        if (textBox != null)
        {
            _ = SendMessageAsync(tab, textBox);
        }
    }

    /// <summary>
    /// Composer içindeki mesaj giriş kutusunu (x:Name="MessageInputBox"),
    /// gönder butonundan başlayarak görsel ağaçta yukarı çıkıp ortak
    /// composer köküne ulaşarak, sonra oradan aşağı inerek bulur.
    /// DataTemplate içindeki x:Name'ler code-behind'dan doğrudan
    /// erişilemediği için (her template kopyası ayrı bir namescope)
    /// bu VisualTreeHelper taraması gerekiyor.
    /// </summary>
    private static TextBox? FindMessageInputBox(DependencyObject start)
    {
        // Önce composer'ın kök Border'ına kadar yukarı çık.
        var current = start;
        while (current != null && current is not Border)
        {
            current = System.Windows.Media.VisualTreeHelper.GetParent(current);
        }

        if (current is null)
        {
            return null;
        }

        return FindDescendant<TextBox>(current);
    }

    private static T? FindDescendant<T>(DependencyObject parent) where T : DependencyObject
    {
        var childCount = System.Windows.Media.VisualTreeHelper.GetChildrenCount(parent);
        for (var i = 0; i < childCount; i++)
        {
            var child = System.Windows.Media.VisualTreeHelper.GetChild(parent, i);
            if (child is T match)
            {
                return match;
            }

            var descendant = FindDescendant<T>(child);
            if (descendant != null)
            {
                return descendant;
            }
        }

        return null;
    }

    private async Task SendMessageAsync(ChatTab tab, TextBox inputTextBox)
    {
        var text = inputTextBox.Text?.Trim();
        if (string.IsNullOrEmpty(text))
        {
            return;
        }

        if (tab.ChatClient is null)
        {
            tab.Messages.Add(new ChatMessage(
                MessageRole.Warning,
                LocalizationManager.Instance.T("MissingApiKeyWarning")));
            return;
        }

        inputTextBox.Clear();
        inputTextBox.IsEnabled = false;

        tab.Messages.Add(new ChatMessage(MessageRole.User, text));

        try
        {
            // Sekmenin tüm görünür geçmişinden (User/Assistant rolleriyle
            // işaretli olanlar) API'nin anlayacağı user/assistant formatına
            // dönüştürülüyor. Warning/Error/System gibi mesajlar asıl
            // konuşmanın parçası değil, bu yüzden API'ye gönderilmiyor —
            // aksi halde model kendi hata mesajlarını "konuşmanın bir
            // parçasıymış" gibi yorumlayabilirdi. Bu karşılaştırma
            // MessageRole enum'ına göre yapıldığı için dil değişse bile
            // (görüntülenen etiketler farklı olsa bile) hep doğru çalışır.
            var conversationHistory = tab.Messages
                .Where(m => m.Role is MessageRole.User or MessageRole.Assistant)
                .Select(m => m.Role == MessageRole.User
                    ? ApiChatMessage.User(m.Content)
                    : ApiChatMessage.Assistant(m.Content))
                .ToList();

            if (tab.ToolsEnabled)
            {
                // Araç modu: streaming yok (tool-calling turları arka
                // planda tamamlanır), sonuç tek seferde gelir. Bu, ilk
                // somut Araç Kütüphanesi entegrasyonu (bkz.
                // Core/Tools/ToolCallingLoop.cs, Bölüm 6.6).
                var toolLoop = new ToolCallingLoop();
                var finalText = await toolLoop.RunAsync(tab.ChatClient, conversationHistory);
                tab.Messages.Add(new ChatMessage(MessageRole.Assistant, finalText));
            }
            else
            {
                // Normal mod: streaming. Boş bir Assistant mesajı ekleyip,
                // gelen her parçayı bu mesajın Content'ine ekliyoruz —
                // ChatMessage artık INotifyPropertyChanged uyguladığı için
                // (bkz. UI/ChatMessage.cs) her ekleme UI'da anında
                // görünür, kullanıcı cevabın "akarak" oluştuğunu görür.
                var responseMessage = new ChatMessage(MessageRole.Assistant, string.Empty);
                tab.Messages.Add(responseMessage);

                await foreach (var chunk in tab.ChatClient.StreamMessageAsync(conversationHistory))
                {
                    responseMessage.Content += chunk;
                }
            }
        }
        catch (Exception ex)
        {
            // İlk iskelette basit hata gösterimi. İleride kullanıcıya
            // daha temiz bir hata/bildirim sistemi ile sunulacak.
            tab.Messages.Add(new ChatMessage(MessageRole.Error, ex.Message));
        }
        finally
        {
            inputTextBox.IsEnabled = true;
            inputTextBox.Focus();
        }
    }
}
