namespace MarathonAI.Core.Settings;

/// <summary>
/// Kullanıcının bilgisayarında local olarak saklanan ayarlar
/// (bkz. docs/MarathonAI_Plan.md, Bölüm 7 — Gizlilik: "sohbetler ve
/// ayarlar local-only, MarathonAI'nin herhangi bir sunucusuna
/// gönderilmez").
///
/// İleride buraya eklenecek alanlar: varsayılan sağlayıcı, dil, tema
/// (koyu/açık — Bölüm 5, 10.1), dosya sistemi erişim kısıtlamaları vb.
/// Şimdilik sadece API anahtarları tutuluyor (ilk somut ihtiyaç).
/// </summary>
public sealed class AppSettings
{
    /// <summary>
    /// Sağlayıcı Id'sinden (bkz. ProviderRegistry) API anahtarına eşleme.
    /// Örn: { "groq": "gsk_...", "openai": "sk-..." }
    /// </summary>
    public Dictionary<string, string> ApiKeys { get; set; } = new();

    /// <summary>
    /// "dark" veya "light" (bkz. ThemeManager, Bölüm 5 ve 10.1).
    /// Varsayılan: "dark".
    /// </summary>
    public string Theme { get; set; } = "dark";

    /// <summary>
    /// Dil kodu ("tr", "en", ...) — bkz. LocalizationManager, Bölüm 5.
    /// Varsayılan: "tr".
    /// </summary>
    public string Language { get; set; } = "tr";
}
