using System.Linq;
using System.Windows;
using System.Windows.Controls;
using MarathonAI.Core.Api;
using MarathonAI.Core.Localization;
using MarathonAI.Core.Settings;

namespace MarathonAI;

/// <summary>
/// Ayarlar penceresi. ProviderRegistry'deki her sağlayıcı için otomatik
/// olarak bir "API Anahtarı" giriş alanı oluşturur — yeni bir sağlayıcı
/// eklendiğinde (bkz. Core/Api/ProviderRegistry.cs) bu pencere kod
/// değişikliği gerekmeden otomatik olarak yeni alanı gösterir.
///
/// Dil ve tema değişikliği anında uygulanır (seçer seçmez ThemeManager/
/// LocalizationManager çağrılır) — kullanıcı değişikliği canlı görür,
/// "Kaydet"e basmasına gerek kalmadan. "Kaydet" butonu sadece API
/// anahtarlarını kalıcı hale getirir (dil/tema zaten anında kaydedilir).
/// </summary>
public partial class SettingsWindow : Window
{
    private readonly Dictionary<string, PasswordBox> _keyInputs = new();
    private bool _isInitializing = true;

    public SettingsWindow()
    {
        InitializeComponent();

        InitializeLanguageSelection();
        InitializeThemeSelection();
        BuildApiKeyFields();

        _isInitializing = false;
    }

    private void InitializeLanguageSelection()
    {
        LanguageComboBox.ItemsSource = LocalizationManager.SupportedLanguages;
        LanguageComboBox.SelectedItem = LocalizationManager.SupportedLanguages
            .FirstOrDefault(l => l.Code == LocalizationManager.Instance.CurrentLanguageCode)
            ?? LocalizationManager.SupportedLanguages[0];
    }

    private void LanguageComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_isInitializing || LanguageComboBox.SelectedItem is not LanguageInfo language)
        {
            return;
        }

        LocalizationManager.Instance.SetLanguageAndSave(language.Code);

        // API anahtarı etiketleri (örn. "Groq API Anahtarı") kod
        // tarafında dinamik oluşturulduğu için binding'lerle otomatik
        // güncellenmiyor — dil değiştiğinde bu alanları yeniden inşa
        // ediyoruz. PasswordBox içindeki mevcut girdiler korunur çünkü
        // BuildApiKeyFields zaten diskteki (kaydedilmiş) değeri okuyor.
        ApiKeyFieldsPanel.Children.Clear();
        _keyInputs.Clear();
        BuildApiKeyFields();
    }

    private void InitializeThemeSelection()
    {
        var currentTheme = ThemeManager.LoadSavedTheme();
        DarkThemeRadio.IsChecked = currentTheme == AppTheme.Dark;
        LightThemeRadio.IsChecked = currentTheme == AppTheme.Light;
    }

    private void ThemeRadio_Checked(object sender, RoutedEventArgs e)
    {
        if (_isInitializing)
        {
            return;
        }

        var selectedTheme = DarkThemeRadio.IsChecked == true ? AppTheme.Dark : AppTheme.Light;
        ThemeManager.Apply(selectedTheme);
        ThemeManager.SaveTheme(selectedTheme);
    }

    private void BuildApiKeyFields()
    {
        var loc = LocalizationManager.Instance;
        var isFirst = true;

        foreach (var provider in ProviderRegistry.All)
        {
            var label = new TextBlock
            {
                Text = $"{provider.DisplayName} {loc.T("ApiKeyFieldSuffix")}",
                Style = (Style)FindResource("EyebrowTextStyle"),
                // İlk alan panelin kendi üst boşluğuna güveniyor, sonraki
                // alanlar önceki PasswordBox'tan ayrılmak için üst boşluk
                // alıyor — böylece dış StackPanel'de tek tip, öngörülebilir
                // bir ritim oluşuyor.
                Margin = isFirst ? new Thickness(0, 8, 0, 8) : new Thickness(0, 20, 0, 8)
            };
            isFirst = false;

            var passwordBox = new PasswordBox
            {
                Style = (Style)FindResource("AppPasswordBoxStyle"),
                // GetKeyByProviderId, diskteki şifrelenmiş değeri okuyup
                // çözüyor (bkz. Core/Api/ApiKeyStore.cs + SecureStore.cs)
                // — burada asla şifreli/ham metin gösterilmiyor.
                Password = ApiKeyStore.GetKeyByProviderId(provider.Id)
            };

            _keyInputs[provider.Id] = passwordBox;

            ApiKeyFieldsPanel.Children.Add(label);
            ApiKeyFieldsPanel.Children.Add(passwordBox);
        }
    }

    private void SaveButton_Click(object sender, RoutedEventArgs e)
    {
        foreach (var (providerId, passwordBox) in _keyInputs)
        {
            ApiKeyStore.SetKey(providerId, passwordBox.Password);
        }

        StatusText.Text = LocalizationManager.Instance.T("SavedStatus");
    }
}
