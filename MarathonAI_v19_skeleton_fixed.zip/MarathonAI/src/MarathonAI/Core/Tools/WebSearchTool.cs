using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using MarathonAI.Core.Api;

namespace MarathonAI.Core.Tools;

/// <summary>
/// MarathonAI'nin kendi web araştırma aracı (bkz. docs/MarathonAI_Plan.md,
/// Bölüm 4 ve 6.6 — "kendi web araştırma aracımız olacak, model bunu
/// kullandığında ham metin çıktısı MarathonAI tarafından temizlenip
/// gösterilecek").
///
/// Tavily API kullanılıyor (https://tavily.com) — AI ajanları için özel
/// tasarlanmış, ücretsiz tier'ı olan (kart bilgisi istemeden 1000
/// kredi/ay) bir arama servisi. API anahtarı, diğer sağlayıcılar gibi
/// Ayarlar penceresinden girilir, SecureStore ile şifrelenmiş saklanır.
///
/// "Ham çıktının kullanıcıdan gizlenmesi" prensibi burada şöyle işliyor:
/// bu araç, modele (kullanıcıya değil) ham arama sonuçlarını JSON olarak
/// verir. Kullanıcı sadece modelin bu sonuçları özümseyip ürettiği nihai,
/// düzenli cevabı görür — arama sonuçlarının kendisi sohbet ekranında
/// hiç görünmez (bkz. MainWindow.xaml, sadece User/Assistant mesajları
/// gösteriliyor, "tool" rolündeki mesajlar transkriptte yer almıyor).
/// </summary>
public sealed class WebSearchTool : IToolHandler
{
    private const string ApiUrl = "https://api.tavily.com/search";
    private static readonly HttpClient HttpClient = new();

    public ToolDefinition Definition { get; } = new(
        Name: "web_search",
        Description: "Güncel bilgi bulmak için web'de arama yapar. Sonuçlar başlık, URL ve kısa içerik özetleri içerir.",
        ParametersJsonSchema: """
        {
          "type": "object",
          "properties": {
            "query": {
              "type": "string",
              "description": "Arama sorgusu"
            }
          },
          "required": ["query"]
        }
        """);

    public async Task<string> ExecuteAsync(string argumentsJson, CancellationToken cancellationToken = default)
    {
        string? query;
        try
        {
            using var doc = JsonDocument.Parse(argumentsJson);
            query = doc.RootElement.GetProperty("query").GetString();
        }
        catch (Exception)
        {
            return BuildErrorResult("Geçersiz araç parametresi (query okunamadı).");
        }

        if (string.IsNullOrWhiteSpace(query))
        {
            return BuildErrorResult("Arama sorgusu boş olamaz.");
        }

        var apiKey = ApiKeyStore.GetTavilyKey();
        if (string.IsNullOrWhiteSpace(apiKey))
        {
            return BuildErrorResult(
                "Web araştırma aracı için API anahtarı bulunamadı. Kullanıcıya, Ayarlar " +
                "penceresinden Tavily API anahtarını girmesi gerektiğini söyle " +
                "(tavily.com üzerinden ücretsiz alınabilir).");
        }

        try
        {
            var requestBody = new
            {
                query,
                max_results = 5,
                search_depth = "basic"
            };

            using var request = new HttpRequestMessage(HttpMethod.Post, ApiUrl)
            {
                Content = new StringContent(JsonSerializer.Serialize(requestBody), Encoding.UTF8, "application/json")
            };
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);

            using var response = await HttpClient.SendAsync(request, cancellationToken);
            var responseText = await response.Content.ReadAsStringAsync(cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                return BuildErrorResult($"Arama isteği başarısız oldu ({(int)response.StatusCode}).");
            }

            // Tavily'nin ham cevabı zaten JSON — modele olduğu gibi
            // aktarılabilir, ekstra ayrıştırmaya gerek yok. Kullanıcı bu
            // ham JSON'ı hiç görmüyor (bkz. sınıf açıklaması), sadece
            // model işleyip nihai cevabı üretiyor.
            return responseText;
        }
        catch (Exception ex)
        {
            return BuildErrorResult($"Arama sırasında hata oluştu: {ex.Message}");
        }
    }

    private static string BuildErrorResult(string message) =>
        JsonSerializer.Serialize(new { success = false, error = message });
}
