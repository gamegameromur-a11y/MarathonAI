# MarathonAI

> Durum: **Alpha / Aktif geliştirme (iskelet aşaması).**

Çoklu AI entegrasyon masaüstü uygulaması (Windows). Detaylı plan için
`docs/MarathonAI_Plan.md` dosyasına bakın.

## Klasör Yapısı

```
MarathonAI/
├── src/
│   └── MarathonAI/          # .NET 8 / WPF proje kökü
│       ├── MarathonAI.csproj
│       ├── App.xaml(.cs)     # Uygulama giriş noktası
│       ├── MainWindow.xaml(.cs)      # Ana pencere: sekme sistemi (TabControl)
│       ├── SettingsWindow.xaml(.cs)  # Ayarlar penceresi: API anahtarı girişleri
│       ├── UI/
│       │   ├── ChatTab.cs                   # Tek bir sekmenin durumu (mesajlar + sağlayıcı)
│       │   ├── ChatMessage.cs               # Paylaşılan mesaj tipi (MessageRole enum dahil)
│       │   └── BoolToAlignmentConverter.cs  # Mesaj hizalaması (kullanıcı sağ, model sol)
│       ├── Themes/
│       │   ├── Styles.xaml       # Tasarım sistemi: tipografi + tüm kontrol şablonları
│       │   ├── Colors.Dark.xaml  # Koyu tema renkleri (siyah zemin, beyaz yazı)
│       │   └── Colors.Light.xaml # Açık tema renkleri (beyaz zemin, siyah yazı)
│       ├── Assets/
│       │   └── Fonts/            # Space Grotesk (.ttf, SIL Open Font License)
│       ├── Resources/
│       │   └── Lang/
│       │       ├── tr.json       # Türkçe çeviriler
│       │       └── en.json       # İngilizce çeviriler
│       └── Core/
│           ├── Api/
│           │   ├── IChatClient.cs                # Sağlayıcı-bağımsız arayüz (streaming)
│           │   ├── ApiChatMessage.cs             # API'ye giden mesaj tipi (user/assistant)
│           │   ├── OpenAiCompatibleChatClient.cs # Ortak temel sınıf (OpenAI SSE streaming formatı)
│           │   ├── OpenAiChatClient.cs           # OpenAI implementasyonu
│           │   ├── GroqChatClient.cs             # Groq implementasyonu (ücretsiz tier)
│           │   ├── ProviderRegistry.cs           # Sağlayıcı listesi/seçim sistemi
│           │   └── ApiKeyStore.cs                # Ayarlardan/ortam değişkeninden key okuma
│           ├── Localization/
│           │   └── LocalizationManager.cs  # JSON tabanlı çalışma zamanı dil sistemi
│           └── Settings/
│               ├── AppSettings.cs      # Ayar veri modeli (API key'ler + tema + dil)
│               ├── SettingsManager.cs  # Diske kaydetme/yükleme (%AppData%)
│               ├── SecureStore.cs      # DPAPI ile API key şifreleme/çözme
│               └── ThemeManager.cs     # Çalışma zamanı koyu/açık tema geçişi
├── docs/             # Plan ve araştırma dokümanları
├── scripts/          # Yardımcı scriptler (DOM inceleme aracı, kullanılmadı)
└── .github/workflows/  # GitHub Actions CI/CD (build.yml)
```

İleride eklenecek klasörler (henüz yok): `Core/Agent` (Mod 1 agent mantığı),
`Core/LocalModels` (Mod 3), `Platforms/` (Mod 2 site adaptörleri — en son
faz).

## Geliştirme Durumu

**Şu an: Onuncu kod iskeleti tamamlandı (Adım 10) — gerçek görsel tasarım.**

Arayüz baştan tasarlandı — bu güne kadar sadece işlevsel/geçici bir
görünümdü, şimdi Bölüm 10.1'deki tasarım kimliğine (tam siyah-beyaz,
Space Grotesk, premium/minimalist) gerçekten uygun:

- **Space Grotesk fontu artık gerçekten projede** (SIL Open Font License,
  `Assets/Fonts/`) — büyük başlıklarda Bold+İtalik, bölüm etiketlerinde
  BÜYÜK HARF+geniş aralık, gövdede sade Regular.
- **Tüm kontroller özel tasarlandı** — Button/TextBox/ComboBox/
  RadioButton/TabControl/ScrollBar artık native WPF "chrome"unu
  (yuvarlak köşe, mavi focus halkası, gradient) kullanmıyor; keskin
  köşe, 1px kenarlık, gri tonsuz.
- **Sohbet transkripti "chat-bubble" değil, editoryal** — kullanıcı
  mesajları sağa hizalı ve sessiz, model mesajları sola hizalı ve güçlü
  tipografiyle ayrışıyor.
- **Sekme çubuğu** klasik "kutu" sekme değil, alt çizgili minimalist bir
  seçici (seçili sekme 2px kalın alt çizgiyle vurgulanıyor).

Henüz: Mod 2/Mod 3, tool-calling, 26 dilin tamamı (şu an sadece tr/en),
sekme kapatma, uygulama ikonu (.ico) YOK — bunlar sıradaki adımlarda
eklenecek.

### Nasıl Derlenir

Bu proje **Windows + .NET 8 SDK** gerektirir (WPF + WebView2 kullanıyor).
Linux/Mac üzerinde derlenemez.

**GitHub Actions ile (önerilen):** `main` dalına push yapıldığında
`.github/workflows/build.yml` otomatik olarak Windows runner'da derler,
derleme çıktısını "Actions" sekmesinden indirebilirsiniz.

**Kendi bilgisayarınızda (Windows + Visual Studio):**
1. [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0) kurun.
2. `src/MarathonAI/MarathonAI.csproj` dosyasını Visual Studio ile açın.
3. F5 ile çalıştırın.
4. Pencerenin sağ üstündeki **"AYARLAR"** butonuna tıklayıp:
   - **Dil** — Türkçe/English arasında seçim yapın (anında uygulanır).
   - **Tema** — Koyu/Açık arasında seçim yapın (anında uygulanır).
   - **API Anahtarı** — En az bir sağlayıcı için anahtar girin (diskte
     şifrelenmiş olarak saklanır):
     - **Groq** — [console.groq.com](https://console.groq.com) üzerinden
       **ücretsiz** hesap açıp alabilirsiniz. Varsayılan sağlayıcı budur.
     - **OpenAI** — kendi OpenAI API anahtarınız (varsa).
5. "+ Yeni Sekme" ile birden fazla bağımsız sohbet açabilir, her
   sekmenin sağ üstündeki menüden o sekmeye özel sağlayıcı seçebilir,
   sohbet devam ederken modeli değiştirebilirsiniz — konuşma geçmişi
   korunur, cevaplar akarak gelir.

(Alternatif/geliştirme amaçlı: `MARATHONAI_GROQ_KEY` / `MARATHONAI_OPENAI_KEY`
ortam değişkenleri de hâlâ çalışıyor, ayarlar panelinde bir key yoksa
buraya bakılıyor.)

Detaylar için `docs/MarathonAI_Plan.md` — Bölüm 9 (Geliştirme Sıralaması).
