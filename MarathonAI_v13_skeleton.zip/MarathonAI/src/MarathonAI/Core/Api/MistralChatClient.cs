namespace MarathonAI.Core.Api;

/// <summary>
/// Mistral AI (La Plateforme) Chat Completions API'sine bağlanan istemci
/// (Mod 1 — Resmi API). Mistral, OpenAI ile aynı endpoint desenini
/// (/v1/chat/completions), aynı mesaj formatını ve aynı SSE streaming
/// protokolünü paylaşıyor — geçiş için sadece base URL, API key ve model
/// adı değişiyor. Bu yüzden OpenAiCompatibleChatClient üzerinden,
/// GroqChatClient ile aynı desende inşa edildi.
/// </summary>
public sealed class MistralChatClient : OpenAiCompatibleChatClient
{
    private const string ApiUrl = "https://api.mistral.ai/v1/chat/completions";

    // mistral-small-latest: hızlı, ücrete duyarlı kullanım için makul bir
    // varsayılan. Kullanıcı ayarlar sisteminden farklı bir Mistral modeli
    // (örn. mistral-large-latest) seçebilecek şekilde ileride
    // genişletilebilir.
    private const string DefaultModel = "mistral-small-latest";

    public MistralChatClient(string apiKey, string model = DefaultModel, System.Net.Http.HttpClient? httpClient = null)
        : base("Mistral", ApiUrl, apiKey, model, httpClient)
    {
    }
}
