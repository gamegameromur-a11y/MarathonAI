using System.Security.Cryptography;
using System.Text;

namespace MarathonAI.Core.Settings;

/// <summary>
/// Windows DPAPI (Data Protection API) kullanarak metni şifreler/çözer.
/// DPAPI'nin avantajı: MarathonAI'nin kendi bir şifre/anahtar yönetmesine
/// gerek yok — şifreleme anahtarı işletim sistemi tarafından, o Windows
/// kullanıcı hesabına bağlı olarak yönetiliyor. Sonuç: şifrelenmiş veriyi
/// SADECE aynı bilgisayarda, aynı Windows hesabıyla giriş yapmış biri
/// çözebilir (bkz. docs/MarathonAI_Plan.md, Bölüm 7 — Gizlilik).
///
/// DataProtectionScope.CurrentUser kullanılıyor (Machine değil) —
/// böylece aynı bilgisayarda başka bir Windows hesabı bu anahtarları
/// okuyamaz.
/// </summary>
public static class SecureStore
{
    // "MarathonAI-ApiKeys-v1": DPAPI'nin isteğe bağlı "entropy" (ek tuz)
    // parametresi. Sabit bir uygulama-özel değer kullanmak, aynı
    // bilgisayardaki başka bir uygulamanın (varsayımsal olarak DPAPI'yi
    // kullanan) bu veriyi kazayla çözememesini sağlar.
    private static readonly byte[] Entropy = Encoding.UTF8.GetBytes("MarathonAI-ApiKeys-v1");

    public static string Encrypt(string plainText)
    {
        if (string.IsNullOrEmpty(plainText))
        {
            return string.Empty;
        }

        var plainBytes = Encoding.UTF8.GetBytes(plainText);
        var encryptedBytes = ProtectedData.Protect(plainBytes, Entropy, DataProtectionScope.CurrentUser);
        return Convert.ToBase64String(encryptedBytes);
    }

    public static string Decrypt(string encryptedBase64)
    {
        if (string.IsNullOrEmpty(encryptedBase64))
        {
            return string.Empty;
        }

        try
        {
            var encryptedBytes = Convert.FromBase64String(encryptedBase64);
            var plainBytes = ProtectedData.Unprotect(encryptedBytes, Entropy, DataProtectionScope.CurrentUser);
            return Encoding.UTF8.GetString(plainBytes);
        }
        catch (Exception)
        {
            // Şifre çözülemiyorsa (örn. ayar dosyası başka bir bilgisayardan
            // kopyalanmış, ya da bozulmuş) boş string döndürülür — kullanıcı
            // API anahtarını tekrar girmek zorunda kalır, ama uygulama
            // çökmez.
            return string.Empty;
        }
    }
}
