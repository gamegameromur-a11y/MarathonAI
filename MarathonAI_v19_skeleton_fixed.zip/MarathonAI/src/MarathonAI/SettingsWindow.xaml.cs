using System.Linq;
using System.Windows;
using System.Windows.Controls;
using MarathonAI.Core.Api;
using MarathonAI.Core.Localization;
using MarathonAI.Core.Settings;

namespace MarathonAI;

/// <summary>
/// Ayarlar penceresi. ProviderRegistry'deki her sağlayıcı için otomatik
/// olarak bir "API Anahtarı" giriş alanı oluşturur — yeni bir sağlayıcı
/// eklendiğinde (bkz. Core/Api/ProviderRegistry.cs) bu pencere kod
/// değişikliği gerekmeden otomatik olarak yeni alanı gösterir.
///
/// Dil ve tema değişikliği anında uygulanır (seçer seçmez ThemeManager/
/// LocalizationManager çağrılır) — kullanıcı değişikliği canlı görür,
/// "Kaydet"e basmasına gerek kalmadan. "Kaydet" butonu sadece API
/// anahtarlarını kalıcı hale getirir (dil/tema zaten anında kaydedilir).
/// </summary>
public partial class SettingsWindow : Window
{
    private readonly Dictionary<string, PasswordBox> _keyInputs = new();
    private bool _isInitializing = true;

    public SettingsWindow()
    {
        InitializeComponent();

        InitializeLanguageSelection();
        InitializeThemeSelection();
        InitializeFileSystemAccessSelection();
        BuildBlockedFoldersList();
        BuildApiKeyFields();

        _isInitializing = false;
    }

    private void InitializeLanguageSelection()
    {
        LanguageComboBox.ItemsSource = LocalizationManager.SupportedLanguages;
        LanguageComboBox.SelectedItem = LocalizationManager.SupportedLanguages
            .FirstOrDefault(l => l.Code == LocalizationManager.Instance.CurrentLanguageCode)
            ?? LocalizationManager.SupportedLanguages[0];
    }

    private void LanguageComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_isInitializing || LanguageComboBox.SelectedItem is not LanguageInfo language)
        {
            return;
        }

        LocalizationManager.Instance.SetLanguageAndSave(language.Code);

        // API anahtarı etiketleri (örn. "Groq API Anahtarı") kod
        // tarafında dinamik oluşturulduğu için binding'lerle otomatik
        // güncellenmiyor — dil değiştiğinde bu alanları yeniden inşa
        // ediyoruz. PasswordBox içindeki mevcut girdiler korunur çünkü
        // BuildApiKeyFields zaten diskteki (kaydedilmiş) değeri okuyor.
        ApiKeyFieldsPanel.Children.Clear();
        _keyInputs.Clear();
        BuildApiKeyFields();
    }

    private void InitializeThemeSelection()
    {
        var currentTheme = ThemeManager.LoadSavedTheme();
        DarkThemeRadio.IsChecked = currentTheme == AppTheme.Dark;
        LightThemeRadio.IsChecked = currentTheme == AppTheme.Light;
    }

    private void ThemeRadio_Checked(object sender, RoutedEventArgs e)
    {
        if (_isInitializing)
        {
            return;
        }

        var selectedTheme = DarkThemeRadio.IsChecked == true ? AppTheme.Dark : AppTheme.Light;
        ThemeManager.Apply(selectedTheme);
        ThemeManager.SaveTheme(selectedTheme);
    }

    private void InitializeFileSystemAccessSelection()
    {
        var settings = SettingsManager.Load();
        FileSystemAccessCheckBox.IsChecked = settings.FileSystemAccessEnabled;
    }

    private void FileSystemAccessCheckBox_Changed(object sender, RoutedEventArgs e)
    {
        if (_isInitializing)
        {
            return;
        }

        var settings = SettingsManager.Load();
        settings.FileSystemAccessEnabled = FileSystemAccessCheckBox.IsChecked == true;
        SettingsManager.Save(settings);
    }

    private void BuildBlockedFoldersList()
    {
        BlockedFoldersPanel.Children.Clear();

        var settings = SettingsManager.Load();
        var loc = LocalizationManager.Instance;

        if (settings.BlockedFolders.Count == 0)
        {
            BlockedFoldersPanel.Children.Add(new TextBlock
            {
                Text = loc.T("NoBlockedFoldersHint"),
                Style = (Style)FindResource("BodyTextStyle"),
                FontSize = (double)FindResource("FontSizeSmall"),
                Opacity = 0.5
            });
            return;
        }

        foreach (var folder in settings.BlockedFolders)
        {
            var row = new Grid();
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var pathText = new TextBlock
            {
                Text = folder,
                Style = (Style)FindResource("BodyTextStyle"),
                FontSize = (double)FindResource("FontSizeSmall"),
                VerticalAlignment = VerticalAlignment.Center,
                TextTrimming = TextTrimming.CharacterEllipsis
            };
            Grid.SetColumn(pathText, 0);

            var removeButton = new Button
            {
                Content = loc.T("RemoveFolderButton"),
                Style = (Style)FindResource("GhostButtonStyle"),
                Tag = folder
            };
            removeButton.Click += RemoveFolderButton_Click;
            Grid.SetColumn(removeButton, 1);

            row.Children.Add(pathText);
            row.Children.Add(removeButton);

            var border = new Border
            {
                Style = (Style)FindResource("RemovableListItemStyle"),
                Child = row
            };

            BlockedFoldersPanel.Children.Add(border);
        }
    }

    private void AddFolderButton_Click(object sender, RoutedEventArgs e)
    {
        // Microsoft.Win32.OpenFolderDialog: .NET 8'de eklenen, ekstra
        // referans (WinForms) gerektirmeyen native klasör seçici.
        var dialog = new Microsoft.Win32.OpenFolderDialog
        {
            Title = LocalizationManager.Instance.T("AddFolderButton"),
            Multiselect = false
        };

        if (dialog.ShowDialog(this) != true)
        {
            return;
        }

        var settings = SettingsManager.Load();
        if (!settings.BlockedFolders.Contains(dialog.FolderName, StringComparer.OrdinalIgnoreCase))
        {
            settings.BlockedFolders.Add(dialog.FolderName);
            SettingsManager.Save(settings);
        }

        BuildBlockedFoldersList();
    }

    private void RemoveFolderButton_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button { Tag: string folderPath })
        {
            return;
        }

        var settings = SettingsManager.Load();
        settings.BlockedFolders.RemoveAll(f => string.Equals(f, folderPath, StringComparison.OrdinalIgnoreCase));
        SettingsManager.Save(settings);

        BuildBlockedFoldersList();
    }

    private void BuildApiKeyFields()
    {
        var loc = LocalizationManager.Instance;
        var isFirst = true;

        void AddField(string displayName, string providerId)
        {
            var label = new TextBlock
            {
                Text = $"{displayName} {loc.T("ApiKeyFieldSuffix")}",
                Style = (Style)FindResource("EyebrowTextStyle"),
                // İlk alan panelin kendi üst boşluğuna güveniyor, sonraki
                // alanlar önceki PasswordBox'tan ayrılmak için üst boşluk
                // alıyor — böylece dış StackPanel'de tek tip, öngörülebilir
                // bir ritim oluşuyor.
                Margin = isFirst ? new Thickness(0, 8, 0, 8) : new Thickness(0, 20, 0, 8)
            };
            isFirst = false;

            var passwordBox = new PasswordBox
            {
                Style = (Style)FindResource("AppPasswordBoxStyle"),
                // GetKeyByProviderId, diskteki şifrelenmiş değeri okuyup
                // çözüyor (bkz. Core/Api/ApiKeyStore.cs + SecureStore.cs)
                // — burada asla şifreli/ham metin gösterilmiyor.
                Password = ApiKeyStore.GetKeyByProviderId(providerId)
            };

            _keyInputs[providerId] = passwordBox;

            ApiKeyFieldsPanel.Children.Add(label);
            ApiKeyFieldsPanel.Children.Add(passwordBox);
        }

        // Her SAĞLAYICI için tek key alanı — kaç modeli olursa olsun
        // (örn. Groq'un 2 modeli var ama tek Groq API key alanı
        // gösterilir, bkz. ProviderRegistry.DistinctApiKeyProviders).
        foreach (var (apiKeyProviderId, displayName) in ProviderRegistry.DistinctApiKeyProviders)
        {
            AddField(displayName, apiKeyProviderId);
        }

        // Tavily bir sohbet sağlayıcısı değil (ProviderRegistry'de yer
        // almıyor), Araç Kütüphanesi'nin (Bölüm 6.6) web araştırma
        // aracını çalıştırmak için kullanılan ayrı bir servis — bu
        // yüzden ayrı, elle eklenen bir alan (bkz. Core/Tools/WebSearchTool.cs).
        AddField("Tavily (Web Araştırma)", "tavily");
    }

    private void SaveButton_Click(object sender, RoutedEventArgs e)
    {
        foreach (var (providerId, passwordBox) in _keyInputs)
        {
            ApiKeyStore.SetKey(providerId, passwordBox.Password);
        }

        StatusText.Text = LocalizationManager.Instance.T("SavedStatus");
    }
}
