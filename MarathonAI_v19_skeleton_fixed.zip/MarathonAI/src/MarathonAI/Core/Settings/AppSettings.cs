namespace MarathonAI.Core.Settings;

/// <summary>
/// Kullanıcının bilgisayarında local olarak saklanan ayarlar
/// (bkz. docs/MarathonAI_Plan.md, Bölüm 7 — Gizlilik: "sohbetler ve
/// ayarlar local-only, MarathonAI'nin herhangi bir sunucusuna
/// gönderilmez").
///
/// İleride buraya eklenecek alanlar: varsayılan sağlayıcı, dil, tema
/// (koyu/açık — Bölüm 5, 10.1), dosya sistemi erişim kısıtlamaları vb.
/// Şimdilik sadece API anahtarları tutuluyor (ilk somut ihtiyaç).
/// </summary>
public sealed class AppSettings
{
    /// <summary>
    /// Sağlayıcı Id'sinden (bkz. ProviderRegistry) API anahtarına eşleme.
    /// Örn: { "groq": "gsk_...", "openai": "sk-..." }
    /// </summary>
    public Dictionary<string, string> ApiKeys { get; set; } = new();

    /// <summary>
    /// "dark" veya "light" (bkz. ThemeManager, Bölüm 5 ve 10.1).
    /// Varsayılan: "dark".
    /// </summary>
    public string Theme { get; set; } = "dark";

    /// <summary>
    /// Dil kodu ("tr", "en", ...) — bkz. LocalizationManager, Bölüm 5.
    /// Varsayılan: "tr".
    /// </summary>
    public string Language { get; set; } = "tr";

    /// <summary>
    /// AI'nin kullanıcının bilgisayarındaki dosyalara erişimi genel
    /// olarak açık mı (bkz. docs/MarathonAI_Plan.md, Bölüm 5 ve Bölüm 3
    /// — Otomasyon Sınırı). Kapalıyken, hiçbir agent/araç dosya sistemi
    /// erişimi talep edemez. Varsayılan: kapalı — kullanıcı bilinçli
    /// olarak açmalı (opt-in), otomatik açık gelmemeli.
    /// </summary>
    public bool FileSystemAccessEnabled { get; set; } = false;

    /// <summary>
    /// AI'nin ASLA erişemeyeceği klasörlerin tam yol listesi (bkz. Bölüm
    /// 5 — "AI'ın giremeyeceği klasörleri seçip AI'ı kısıtlayabileceği
    /// bir ayar"). FileSystemAccessEnabled açık olsa bile bu listedeki
    /// klasörler her zaman yasaktır — bu, genel açma/kapama anahtarının
    /// üzerinde, ikinci bir güvenlik katmanı olarak çalışır (bkz. Bölüm
    /// 6.3 — "model kendi kendini sınırlar" varsayımına güvenilmeyeceği,
    /// MarathonAI'nin kendi teknik izin/sandbox katmanını kuracağı
    /// prensibi).
    /// </summary>
    public List<string> BlockedFolders { get; set; } = new();
}
