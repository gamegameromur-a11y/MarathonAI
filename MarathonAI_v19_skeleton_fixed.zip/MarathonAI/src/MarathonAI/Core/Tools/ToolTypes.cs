namespace MarathonAI.Core.Tools;

/// <summary>
/// Modelin çağırabileceği bir aracın tanımı — API'ye "işte kullanabileceğin
/// araçlar" olarak gönderilir (bkz. docs/MarathonAI_Plan.md, Bölüm 6.6 —
/// MarathonAI Araç Kütüphanesi). ParametersJsonSchema, aracın hangi
/// parametreleri kabul ettiğini JSON Schema formatında tanımlar — bu,
/// OpenAI/Groq/Mistral'in "function calling" özelliğinin standart
/// beklediği format.
/// </summary>
public sealed record ToolDefinition(
    string Name,
    string Description,
    string ParametersJsonSchema);

/// <summary>
/// Modelin bir aracı çağırma isteği — API cevabından ayrıştırılır.
/// </summary>
public sealed record ToolCallRequest(
    string Id,
    string ToolName,
    string ArgumentsJson);

/// <summary>
/// Bir aracın çalıştırılma sonucu — modele geri gönderilir.
/// </summary>
public sealed record ToolCallResult(string ToolCallId, string ResultJson);

/// <summary>
/// MarathonAI'nin gerçekte çalıştırdığı bir aracın implementasyonu.
/// ToolDefinition sadece "modele ne söyleyeceğimizi" tanımlar; IToolHandler
/// ise "model bu aracı çağırınca gerçekte ne olacağını" tanımlar (bkz.
/// Core/Tools/ReadFileTool.cs — ilk somut örnek).
/// </summary>
public interface IToolHandler
{
    ToolDefinition Definition { get; }

    Task<string> ExecuteAsync(string argumentsJson, CancellationToken cancellationToken = default);
}
