namespace MarathonAI.Core.Tools;

/// <summary>
/// Desteklenen kod çalıştırma dilleri (bkz. docs/MarathonAI_Plan.md,
/// Bölüm 6.2 — "kod çalışma alanları: C++, Python, Rust").
/// </summary>
public enum CodeLanguage
{
    Python,
    Cpp,
    Rust
}

/// <summary>
/// Bir kod çalıştırma işleminin sonucu.
/// </summary>
public sealed record CodeExecutionResult(
    bool Success,
    string StandardOutput,
    string StandardError,
    int? ExitCode,
    bool TimedOut);

/// <summary>
/// Her dilin kendi derleme/çalıştırma stratejisini tanımlayan arayüz.
/// Python doğrudan yorumlanır; C++ ve Rust önce derlenir, sonra derlenen
/// binary çalıştırılır — bu arayüz bu farkı soyutluyor, ExecuteAsync
/// çağıran taraf için hep aynı görünür.
/// </summary>
public interface ICodeRunner
{
    CodeLanguage Language { get; }

    Task<CodeExecutionResult> RunAsync(string code, TimeSpan timeout, CancellationToken cancellationToken = default);
}
