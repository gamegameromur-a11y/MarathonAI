using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;

namespace MarathonAI.Core.Api;

/// <summary>
/// OpenAI'ın Chat Completions API formatını (aynı endpoint yapısı, aynı
/// istek/cevap şeması, aynı SSE tabanlı streaming protokolü) paylaşan
/// sağlayıcılar için ortak temel sınıf.
///
/// Bu format, OpenAI'ın kendisi dışında birçok sağlayıcı tarafından da
/// benimsendi (Groq, Mistral, OpenRouter, DeepSeek ve daha fazlası) —
/// çoğu zaman değişen tek şey base URL ve model adı. Bu yüzden her
/// sağlayıcı için sıfırdan HTTP/JSON kodu yazmak yerine, ortak mantık
/// burada tek yerde tutuluyor; her sağlayıcı sınıfı sadece kendine özgü
/// sabitleri (URL, varsayılan model) sağlıyor.
///
/// İleride Claude/Gemini gibi farklı bir istek şeması kullanan
/// sağlayıcılar için ayrı, kendi IChatClient implementasyonları
/// yazılacak (bu temel sınıfı kullanmayacaklar).
/// </summary>
public abstract class OpenAiCompatibleChatClient : IChatClient
{
    private readonly HttpClient _httpClient;
    private readonly string _apiKey;
    private readonly string _model;
    private readonly string _apiUrl;

    protected OpenAiCompatibleChatClient(
        string providerDisplayName,
        string apiUrl,
        string apiKey,
        string model,
        HttpClient? httpClient = null)
    {
        if (string.IsNullOrWhiteSpace(apiKey))
        {
            throw new InvalidOperationException(
                $"{providerDisplayName} API anahtarı bulunamadı. Lütfen Ayarlar " +
                "penceresinden kendi API anahtarınızı girin.");
        }

        _apiUrl = apiUrl;
        _apiKey = apiKey;
        _model = model;
        _httpClient = httpClient ?? new HttpClient();
    }

    /// <summary>
    /// Cevabı SSE (Server-Sent Events) formatında, parça parça alır ve
    /// her metin parçasını olduğu gibi döndürür. Bu, OpenAI ve
    /// OpenAI-uyumlu sağlayıcıların (Groq dahil) standart streaming
    /// protokolü: her satır "data: {...}" şeklinde bir JSON parçası
    /// taşır, akış "data: [DONE]" ile biter.
    /// </summary>
    public async IAsyncEnumerable<string> StreamMessageAsync(
        IReadOnlyList<ApiChatMessage> conversationHistory,
        [EnumeratorCancellation] CancellationToken cancellationToken = default)
    {
        var requestBody = new
        {
            model = _model,
            messages = conversationHistory
                .Select(m => new { role = m.Role, content = m.Content })
                .ToArray(),
            stream = true
        };

        var json = JsonSerializer.Serialize(requestBody);

        using var request = new HttpRequestMessage(HttpMethod.Post, _apiUrl)
        {
            Content = new StringContent(json, Encoding.UTF8, "application/json")
        };
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _apiKey);

        using var response = await _httpClient.SendAsync(
            request, HttpCompletionOption.ResponseHeadersRead, cancellationToken);

        if (!response.IsSuccessStatusCode)
        {
            var errorText = await response.Content.ReadAsStringAsync(cancellationToken);
            throw new InvalidOperationException(
                $"API isteği başarısız oldu ({(int)response.StatusCode}): {errorText}");
        }

        await using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);
        using var reader = new StreamReader(stream);

        while (!reader.EndOfStream)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var line = await reader.ReadLineAsync(cancellationToken);
            if (string.IsNullOrWhiteSpace(line) || !line.StartsWith("data: "))
            {
                continue;
            }

            var payload = line["data: ".Length..];
            if (payload == "[DONE]")
            {
                yield break;
            }

            string? deltaContent;
            try
            {
                using var doc = JsonDocument.Parse(payload);
                deltaContent = doc.RootElement
                    .GetProperty("choices")[0]
                    .GetProperty("delta")
                    .TryGetProperty("content", out var contentProp)
                        ? contentProp.GetString()
                        : null;
            }
            catch (JsonException)
            {
                // Beklenmeyen/bozuk bir SSE parçası — akışı kesmek yerine
                // bu parçayı atlayıp devam ediyoruz. Sık tekrarlanırsa
                // ileride burada bir hata sayacı/loglama eklenebilir.
                continue;
            }

            if (!string.IsNullOrEmpty(deltaContent))
            {
                yield return deltaContent;
            }
        }
    }
}
