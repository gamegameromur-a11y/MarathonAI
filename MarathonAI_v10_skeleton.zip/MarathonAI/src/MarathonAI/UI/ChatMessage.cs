using System.ComponentModel;

namespace MarathonAI.UI;

/// <summary>
/// Bir sohbet mesajının kim tarafından yazıldığını, dilden bağımsız
/// sabit bir kimlikle belirtir. Bu enum, "Sen"/"You" gibi görüntülenen
/// metinlerden kasıtlı olarak AYRI tutuluyor — dil değiştiğinde (bkz.
/// LocalizationManager) görüntülenen etiket değişse bile, kod
/// tarafındaki mantık (örn. "hangi mesajlar API'ye gönderilecek" filtresi
/// MainWindow.xaml.cs içinde) hep bu sabit değerlere göre çalışır, asla
/// kırılmaz.
/// </summary>
public enum MessageRole
{
    User,
    Assistant,
    Warning,
    Error,
    System
}

/// <summary>
/// Sohbet geçmişindeki tek bir mesajı temsil eder (kullanıcı veya model).
/// INotifyPropertyChanged uyguluyor çünkü streaming sırasında Content
/// parça parça güncelleniyor — ObservableCollection sadece eleman
/// ekleme/çıkarmayı izler, mevcut bir elemanın içindeki property
/// değişikliğini değil; bu yüzden mesajın kendisinin değişikliği
/// bildirmesi gerekiyor ki UI (TextBlock binding'i) anında güncellensin.
/// </summary>
public sealed class ChatMessage : INotifyPropertyChanged
{
    private string _content;

    public MessageRole Role { get; }

    /// <summary>
    /// XAML'da görüntülenen etiket. LocalizationManager'ın o an seçili
    /// dilindeki karşılığını döndürür (bkz. Resources/Lang/*.json,
    /// anahtarlar: RoleUser, RoleAssistant, RoleWarning, RoleError,
    /// RoleSystem).
    /// </summary>
    public string RoleDisplayName => Role switch
    {
        MessageRole.User => Core.Localization.LocalizationManager.Instance.T("RoleUser"),
        MessageRole.Assistant => Core.Localization.LocalizationManager.Instance.T("RoleAssistant"),
        MessageRole.Warning => Core.Localization.LocalizationManager.Instance.T("RoleWarning"),
        MessageRole.Error => Core.Localization.LocalizationManager.Instance.T("RoleError"),
        MessageRole.System => Core.Localization.LocalizationManager.Instance.T("RoleSystem"),
        _ => Role.ToString()
    };

    public string Content
    {
        get => _content;
        set
        {
            if (_content == value)
            {
                return;
            }

            _content = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Content)));
        }
    }

    /// <summary>
    /// XAML'da mesaj hizalamasını (sağ/sol) belirlemek için kullanılır —
    /// bkz. MainWindow.xaml, BoolToAlignmentConverter. Sadece User
    /// mesajları sağa hizalanır, geri kalan her şey (Assistant, Warning,
    /// Error, System) sola hizalanır.
    /// </summary>
    public bool IsUserMessage => Role == MessageRole.User;

    public ChatMessage(MessageRole role, string content)
    {
        Role = role;
        _content = content;
    }

    public event PropertyChangedEventHandler? PropertyChanged;
}
