using System.ComponentModel;
using System.IO;
using System.Text.Json;
using MarathonAI.Core.Settings;

namespace MarathonAI.Core.Localization;

/// <summary>
/// Bilinen bir dili tanımlar (bkz. docs/MarathonAI_Plan.md, Bölüm 5 —
/// "26 dile kadar" hedefi). Şu an sadece iki dil dosyası var (tr, en),
/// ama sistem yeni bir dil eklemeyi kolaylaştıracak şekilde tasarlandı:
/// yeni bir .json dosyası Resources/Lang altına eklenip aşağıdaki
/// SupportedLanguages listesine bir satır eklemek yeterli.
/// </summary>
public sealed record LanguageInfo(string Code, string DisplayName);

/// <summary>
/// JSON tabanlı, çalışma zamanında dil değiştirmeyi destekleyen basit bir
/// yerelleştirme sistemi. RESX yerine JSON tercih edildi çünkü:
///   - Çalışma zamanında (uygulamayı yeniden başlatmadan) dil değiştirmek
///     RESX'e göre çok daha kolay.
///   - 26 dile çıkarken yeni dil eklemek sadece yeni bir .json dosyası
///     eklemek kadar basit kalıyor.
///
/// Kullanım: Localization.T("SettingsButton") gibi bir anahtar ile
/// çağrılır, o an seçili dildeki karşılığını döndürür. Anahtar
/// bulunamazsa (örn. yeni bir dile henüz çeviri eklenmemişse) anahtarın
/// kendisi döndürülür — uygulama hiçbir zaman boş/kırık bir metinle
/// çökmez.
/// </summary>
public sealed class LocalizationManager : INotifyPropertyChanged
{
    public static LocalizationManager Instance { get; } = new();

    public static IReadOnlyList<LanguageInfo> SupportedLanguages { get; } = new List<LanguageInfo>
    {
        new("tr", "Türkçe"),
        new("en", "English"),
    };

    private Dictionary<string, string> _translations = new();
    private string _currentLanguageCode = "tr";

    public string CurrentLanguageCode => _currentLanguageCode;

    public event PropertyChangedEventHandler? PropertyChanged;

    private LocalizationManager()
    {
        var savedCode = SettingsManager.Load().Language;
        SetLanguage(string.IsNullOrWhiteSpace(savedCode) ? "tr" : savedCode);
    }

    public void SetLanguage(string languageCode)
    {
        _translations = LoadTranslations(languageCode);
        _currentLanguageCode = languageCode;

        // "T" indexer'ının kendisi değişmiyor ama içeriği değişti — WPF
        // binding'lerinin (Binding Path=T[SettingsButton]) yenilenmesi
        // için Item[] property'sinin değiştiğini bildiriyoruz. Bu, WPF'in
        // indexer binding'lerini güncellemesi için standart yöntemdir.
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Item[]"));
    }

    /// <summary>
    /// Dili hem çalışma zamanında uygular hem de kalıcı olarak ayarlara
    /// kaydeder (bir sonraki açılışta da korunur). Ayarlar penceresinden
    /// çağrılır.
    /// </summary>
    public void SetLanguageAndSave(string languageCode)
    {
        SetLanguage(languageCode);

        var settings = SettingsManager.Load();
        settings.Language = languageCode;
        SettingsManager.Save(settings);
    }

    /// <summary>
    /// XAML'dan `{Binding T[AnahtarAdı], Source={x:Static loc:LocalizationManager.Instance}}`
    /// şeklinde kullanılabilecek indexer. Kod tarafında ise
    /// LocalizationManager.Instance.T["AnahtarAdı"] şeklinde okunur.
    /// </summary>
    public string this[string key] => _translations.TryGetValue(key, out var value) ? value : key;

    /// <summary>Kod tarafında kısa kullanım için: Loc.T("AnahtarAdı")</summary>
    public string T(string key) => this[key];

    private static Dictionary<string, string> LoadTranslations(string languageCode)
    {
        try
        {
            var path = Path.Combine(AppContext.BaseDirectory, "Resources", "Lang", $"{languageCode}.json");
            if (!File.Exists(path))
            {
                return new Dictionary<string, string>();
            }

            var json = File.ReadAllText(path);
            return JsonSerializer.Deserialize<Dictionary<string, string>>(json) ?? new Dictionary<string, string>();
        }
        catch (Exception)
        {
            // Dil dosyası okunamıyorsa (bozuk/eksik), boş sözlükle devam
            // edilir — this[key] anahtarın kendisini döndürdüğü için
            // uygulama çökmez, sadece çeviriler yerine anahtar isimleri
            // görünür.
            return new Dictionary<string, string>();
        }
    }
}
