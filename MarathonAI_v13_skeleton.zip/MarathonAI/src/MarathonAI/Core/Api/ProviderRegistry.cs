namespace MarathonAI.Core.Api;

/// <summary>
/// Kullanılabilir bir sağlayıcıyı (OpenAI, Groq, vb.) tanımlar.
/// </summary>
public sealed record ProviderInfo(string Id, string DisplayName, Func<IChatClient> CreateClient);

/// <summary>
/// Mod 1'de (Resmi API) desteklenen tüm sağlayıcıların merkezi listesi.
/// Yeni bir sağlayıcı eklemek (örn. DeepSeek, OpenRouter) istendiğinde
/// tek yapılması gereken:
///   1. O sağlayıcı için IChatClient implementasyonu yazmak (genelde
///      OpenAiCompatibleChatClient'tan türeyerek, bkz. GroqChatClient.cs)
///   2. Aşağıdaki listeye bir satır eklemek
/// Böylece hem MainWindow hem ileride sekme/model seçim sistemi otomatik
/// olarak yeni sağlayıcıyı tanır — MarathonAI'nin "10+ AI" hedefinin
/// (bkz. docs/MarathonAI_Plan.md, Bölüm 1) somut altyapısı budur.
/// </summary>
public static class ProviderRegistry
{
    public static IReadOnlyList<ProviderInfo> All { get; } = new List<ProviderInfo>
    {
        new(
            Id: "groq",
            DisplayName: "Groq (ücretsiz)",
            CreateClient: () => new GroqChatClient(ApiKeyStore.GetGroqKey())
        ),
        new(
            Id: "openai",
            DisplayName: "OpenAI",
            CreateClient: () => new OpenAiChatClient(ApiKeyStore.GetOpenAiKey())
        ),
        new(
            Id: "mistral",
            DisplayName: "Mistral",
            CreateClient: () => new MistralChatClient(ApiKeyStore.GetMistralKey())
        ),
    };

    /// <summary>
    /// Varsayılan sağlayıcı: Groq. Sebep: kullanıcının kendi API anahtarı
    /// olmasa bile Groq'un ücretsiz tier'ı üzerinden uygulamayı hemen
    /// deneyebilmesi hedefleniyor (bkz. docs/MarathonAI_Plan.md, Bölüm 1).
    /// </summary>
    public static ProviderInfo Default => All[0];

    public static ProviderInfo? FindById(string id) => All.FirstOrDefault(p => p.Id == id);
}
