using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace MarathonAI.UI;

/// <summary>
/// ChatMessage.IsUserMessage (bool) değerini HorizontalAlignment'a
/// çevirir — kullanıcı mesajları sağa, model/sistem mesajları sola
/// hizalanır (bkz. MainWindow.xaml, sohbet transkripti şablonu).
/// </summary>
public sealed class BoolToAlignmentConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        var isUserMessage = value is true;
        return isUserMessage ? HorizontalAlignment.Right : HorizontalAlignment.Left;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
        throw new NotSupportedException("BoolToAlignmentConverter sadece tek yönlü (one-way) kullanılır.");
    }
}
