using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace MarathonAI.UI;

/// <summary>
/// true → Visible, false → Collapsed. HasMessages gibi bool
/// property'leri, boş durum (empty state) gösterimini kontrol etmek
/// için Visibility'ye çevirir (bkz. MainWindow.xaml).
/// </summary>
public sealed class BoolToVisibilityConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) =>
        value is true ? Visibility.Visible : Visibility.Collapsed;

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) =>
        throw new NotSupportedException("BoolToVisibilityConverter sadece tek yönlü (one-way) kullanılır.");
}

/// <summary>
/// Tersi: true → Collapsed, false → Visible. Aynı bool değeri (örn.
/// HasMessages) iki farklı elemanın (transkript / boş durum ipucu)
/// görünürlüğünü zıt şekilde kontrol etmek için kullanılıyor.
/// </summary>
public sealed class InverseBoolToVisibilityConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) =>
        value is true ? Visibility.Collapsed : Visibility.Visible;

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) =>
        throw new NotSupportedException("InverseBoolToVisibilityConverter sadece tek yönlü (one-way) kullanılır.");
}
