# MarathonAI

> Durum: **Alpha / Aktif geliştirme (iskelet aşaması).**

Çoklu AI entegrasyon masaüstü uygulaması (Windows). Detaylı plan için
`docs/MarathonAI_Plan.md` dosyasına bakın.

## Klasör Yapısı

```
MarathonAI/
├── src/
│   └── MarathonAI/          # .NET 8 / WPF proje kökü
│       ├── MarathonAI.csproj
│       ├── App.xaml(.cs)     # Uygulama giriş noktası
│       ├── MainWindow.xaml(.cs)      # Ana pencere: sekme sistemi (TabControl)
│       ├── SettingsWindow.xaml(.cs)  # Ayarlar penceresi: API anahtarı girişleri
│       ├── UI/
│       │   ├── ChatTab.cs                   # Tek bir sekmenin durumu (mesajlar + sağlayıcı)
│       │   ├── ChatMessage.cs               # Paylaşılan mesaj tipi (MessageRole enum dahil)
│       │   └── BoolToAlignmentConverter.cs  # Mesaj hizalaması (kullanıcı sağ, model sol)
│       ├── Themes/
│       │   ├── Styles.xaml       # Tasarım sistemi: tipografi + tüm kontrol şablonları
│       │   ├── Colors.Dark.xaml  # Koyu tema renkleri (siyah zemin, beyaz yazı)
│       │   └── Colors.Light.xaml # Açık tema renkleri (beyaz zemin, siyah yazı)
│       ├── Assets/
│       │   └── Fonts/            # Space Grotesk (.ttf, SIL Open Font License)
│       ├── Resources/
│       │   └── Lang/
│       │       ├── tr.json       # Türkçe çeviriler
│       │       └── en.json       # İngilizce çeviriler
│       └── Core/
│           ├── Api/
│           │   ├── IChatClient.cs                # Sağlayıcı-bağımsız arayüz (streaming)
│           │   ├── ApiChatMessage.cs             # API'ye giden mesaj tipi (user/assistant)
│           │   ├── OpenAiCompatibleChatClient.cs # Ortak temel sınıf (OpenAI SSE streaming formatı)
│           │   ├── OpenAiChatClient.cs           # OpenAI implementasyonu
│           │   ├── GroqChatClient.cs             # Groq implementasyonu (ücretsiz tier)
│           │   ├── MistralChatClient.cs          # Mistral implementasyonu
│           │   ├── ProviderRegistry.cs           # Sağlayıcı listesi/seçim sistemi
│           │   └── ApiKeyStore.cs                # Ayarlardan/ortam değişkeninden key okuma
│           ├── Localization/
│           │   └── LocalizationManager.cs  # JSON tabanlı çalışma zamanı dil sistemi
│           └── Settings/
│               ├── AppSettings.cs      # Ayar veri modeli (API key'ler + tema + dil)
│               ├── SettingsManager.cs  # Diske kaydetme/yükleme (%AppData%)
│               ├── SecureStore.cs      # DPAPI ile API key şifreleme/çözme
│               └── ThemeManager.cs     # Çalışma zamanı koyu/açık tema geçişi
├── docs/             # Plan ve araştırma dokümanları
├── scripts/          # Yardımcı scriptler (DOM inceleme aracı, kullanılmadı)
└── .github/workflows/  # GitHub Actions CI/CD (build.yml)
```

İleride eklenecek klasörler (henüz yok): `Core/Agent` (Mod 1 agent mantığı),
`Core/LocalModels` (Mod 3), `Platforms/` (Mod 2 site adaptörleri — en son
faz).

## Geliştirme Durumu

**Şu an: On üçüncü kod iskeleti tamamlandı (Adım 13).**

**Proje ilerlemesi: ~%16**

Space Grotesk fontu, daha güvenilir bir yöntemle (göreli pack URI:
`./Assets/Fonts/#Space Grotesk`) tekrar denendi — bu format Microsoft'un
resmi dokümantasyonunda önerilen, daha tutarlı çalışan yöntem. Eğer bu
ortamda yine yüklenmezse, WPF otomatik olarak sistem fontuna düşecek —
**metin görünmez hale gelmeyecek**, sadece görünüm sistem fontuyla olacak
(Adım 12'de düzeltilen asıl kritik hata bu değildi, ayrı bir
`ContentPresenter`/`Foreground` miras sorunuydu, o düzeltme kalıcı).

Bu adımı test edip font'un doğru göründüğünü (veya sorunsuz şekilde
sistem fontuna düştüğünü) onaylamak faydalı olur.

Henüz: Mod 2/Mod 3, tool-calling, 26 dilin tamamı (şu an sadece tr/en),
sekme kapatma YOK — bunlar sıradaki adımlarda eklenecek.

### Nasıl Derlenir

Bu proje **Windows + .NET 8 SDK** gerektirir (WPF + WebView2 kullanıyor).
Linux/Mac üzerinde derlenemez.

**GitHub Actions ile (önerilen):** `main` dalına push yapıldığında
`.github/workflows/build.yml` otomatik olarak Windows runner'da derler,
derleme çıktısını "Actions" sekmesinden indirebilirsiniz.

**Kendi bilgisayarınızda (Windows + Visual Studio):**
1. [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0) kurun.
2. `src/MarathonAI/MarathonAI.csproj` dosyasını Visual Studio ile açın.
3. F5 ile çalıştırın.
4. Pencerenin sağ üstündeki **"AYARLAR"** butonuna tıklayıp:
   - **Dil** — Türkçe/English arasında seçim yapın (anında uygulanır).
   - **Tema** — Koyu/Açık arasında seçim yapın (anında uygulanır).
   - **API Anahtarı** — En az bir sağlayıcı için anahtar girin (diskte
     şifrelenmiş olarak saklanır):
     - **Groq** — [console.groq.com](https://console.groq.com) üzerinden
       **ücretsiz** hesap açıp alabilirsiniz. Varsayılan sağlayıcı budur.
     - **OpenAI** — kendi OpenAI API anahtarınız (varsa).
     - **Mistral** — kendi Mistral API anahtarınız (varsa,
       [console.mistral.ai](https://console.mistral.ai) üzerinden).
5. "+ Yeni Sekme" ile birden fazla bağımsız sohbet açabilir, her
   sekmenin sağ üstündeki menüden o sekmeye özel sağlayıcı seçebilir,
   sohbet devam ederken modeli değiştirebilirsiniz — konuşma geçmişi
   korunur, cevaplar akarak gelir.

(Alternatif/geliştirme amaçlı: `MARATHONAI_GROQ_KEY` / `MARATHONAI_OPENAI_KEY`
ortam değişkenleri de hâlâ çalışıyor, ayarlar panelinde bir key yoksa
buraya bakılıyor.)

Detaylar için `docs/MarathonAI_Plan.md` — Bölüm 9 (Geliştirme Sıralaması).
