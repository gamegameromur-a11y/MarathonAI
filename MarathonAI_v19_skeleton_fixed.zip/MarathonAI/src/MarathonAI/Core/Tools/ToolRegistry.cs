using System.Linq;

namespace MarathonAI.Core.Tools;

/// <summary>
/// MarathonAI'nin sunduğu tüm araçların merkezi listesi (bkz.
/// docs/MarathonAI_Plan.md, Bölüm 6.6). Yeni bir araç eklemek için tek
/// yapılması gereken: IToolHandler'ı implemente eden bir sınıf yazmak
/// (bkz. ReadFileTool.cs) ve aşağıdaki listeye eklemek — Agent modu
/// otomatik olarak yeni aracı modele tanıtır.
/// </summary>
public static class ToolRegistry
{
    public static IReadOnlyList<IToolHandler> All { get; } = new List<IToolHandler>
    {
        new ReadFileTool(),
        new WebSearchTool(),
        new DeepResearchTool(),
    };

    public static IToolHandler? FindByName(string name) =>
        All.FirstOrDefault(t => t.Definition.Name == name);
}
