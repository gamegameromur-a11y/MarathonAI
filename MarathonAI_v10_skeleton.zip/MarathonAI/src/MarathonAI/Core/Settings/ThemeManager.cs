using System.Linq;
using System.Windows;

namespace MarathonAI.Core.Settings;

public enum AppTheme
{
    Dark,
    Light
}

/// <summary>
/// Uygulama genelinde koyu/açık tema arasında çalışma zamanında geçiş
/// yapar (bkz. docs/MarathonAI_Plan.md, Bölüm 5 ve 10.1). Application
/// kaynak sözlüklerinden (App.xaml.Resources.MergedDictionaries) sadece
/// renk sözlüğünü (Colors.Dark.xaml / Colors.Light.xaml) değiştirir;
/// Styles.xaml'daki stiller DynamicResource kullandığı için otomatik
/// olarak yeni renklere göre güncellenir.
/// </summary>
public static class ThemeManager
{
    private const string DarkColorsUri = "Themes/Colors.Dark.xaml";
    private const string LightColorsUri = "Themes/Colors.Light.xaml";

    public static void Apply(AppTheme theme)
    {
        var dictionaries = Application.Current.Resources.MergedDictionaries;

        var existingColorDict = dictionaries.FirstOrDefault(d =>
            d.Source != null &&
            (d.Source.OriginalString.Contains("Colors.Dark.xaml") ||
             d.Source.OriginalString.Contains("Colors.Light.xaml")));

        if (existingColorDict != null)
        {
            dictionaries.Remove(existingColorDict);
        }

        var newUri = theme == AppTheme.Dark ? DarkColorsUri : LightColorsUri;
        dictionaries.Add(new ResourceDictionary { Source = new Uri(newUri, UriKind.Relative) });
    }

    /// <summary>
    /// Ayarlarda kayıtlı temayı okur; kayıt yoksa varsayılan olarak
    /// koyu tema döner.
    /// </summary>
    public static AppTheme LoadSavedTheme()
    {
        var settings = SettingsManager.Load();
        return settings.Theme == "light" ? AppTheme.Light : AppTheme.Dark;
    }

    public static void SaveTheme(AppTheme theme)
    {
        var settings = SettingsManager.Load();
        settings.Theme = theme == AppTheme.Light ? "light" : "dark";
        SettingsManager.Save(settings);
    }
}
