# MarathonAI — Arayüz Geliştirme Görevi (Replit için Prompt)

MarathonAI adlı bir Windows masaüstü uygulaması üzerinde çalışıyorsun.
**C# / .NET 8 / WPF.** Aşağıda mevcut arayüzün **tam, satır satır**
dökümünü bulacaksın — hangi elemanın nerede olduğu, ne yazdığı, hangi
koda bağlı olduğu. Lütfen bunu sadık kalınması gereken bir referans
olarak kullan, tahmin yürütme.

---

## 1. MEVCUT EKRAN DÖKÜMÜ — Ana Pencere (`MainWindow.xaml`)

Pencere: 1180×760px başlangıç boyutu, minimum 820×560px. Tam ekran
değil, ortalanmış normal bir pencere.

### 1.1 Üst Şerit (dış kenardan 32px sol/sağ, 24px üst, 20px alt boşluk)
Yatayda 3 bölge, soldan sağa:

| Sıra | Eleman | İçerik | Stil |
|---|---|---|---|
| 1 (esnek, kalan tüm alanı kaplar) | Başlık metni | "MARATHONAI" (dilden bağımsız, her zaman büyük harf) | `DisplayTextStyle`: Bold+İtalik, büyük punto |
| 2 (içeriğe göre dar) | Buton | "AYARLAR" (TR) / "SETTINGS" (EN) | `AppButtonStyle`, sağ marjı 10px |
| 3 (içeriğe göre dar) | Buton | "+ YENİ SEKME" (TR) / "+ NEW TAB" (EN) | `AppButtonStyle` |

Bu 3 eleman **tek bir yatay Grid satırında**, dikey ortalı.

### 1.2 İnce Ayraç Çizgisi
Üst şeridin hemen altında, tam genişlikte, **1px yükseklik**, ana metin
renginin %12 opaklığı. Bölüm ayırıcı olarak kullanılıyor, kalın border
DEĞİL.

### 1.3 Sekme Çubuğu + İçerik (dış kenardan 32px sol/sağ, 20px üst, 24px alt)
- **Sekme başlıkları:** Her sekme "Sekme 1", "Sekme 2" gibi otomatik
  numaralı bir isim taşır (TR: "Sekme N", EN: "Tab N"). Sekme başlıkları
  arasında 28px sağ boşluk var. **Klasik "kutu" sekme görünümü değil**
  — alt çizgili, minimalist. Seçili sekmenin altında 2px kalın bir
  çizgi (ana renk) belirir; seçili olmayan sekmeler %45 opaklıkta
  görünür.
- Her sekmenin İÇERİĞİ üç dikey bölgeden oluşur (üstten alta):

**(a) Sağlayıcı seçici satırı** (alt boşluk 20px):
- Bu satır 3 sütunlu bir Grid: [esnek boşluk] [Araçlar checkbox] [model ComboBox]
- **Sağdan 2. eleman:** CheckBox, metni "Araçlar" (TR) / "Tools" (EN).
  Sağ marjı 16px. Kare çerçeveli işaretçi (native tik işareti DEĞİL).
- **En sağdaki eleman:** ComboBox, genişlik 200px. Bu ComboBox **model
  seçicidir** — şu an listede şu değerler var (örnek, gerçek liste
  `Core/Api/ProviderRegistry.cs`'de tanımlı):
  - "Groq — Llama 3.3 70B (ücretsiz)"
  - "Groq — Llama 3.1 8B (hızlı, ücretsiz)"
  - "OpenAI — GPT-4o"
  - "OpenAI — GPT-4o mini"
  - "Mistral — Large"
  - "Mistral — Small"
  
  **ÖNEMLİ:** Bu bir "sağlayıcı" seçici değil, "sağlayıcı + spesifik
  model" seçicidir — yani kullanıcı sadece "OpenAI" seçmiyor, doğrudan
  "OpenAI — GPT-4o" gibi somut bir model seçiyor. Yeni bir model
  eklemek istersen `ProviderRegistry.All` listesine yeni bir satır
  eklemen yeterli, ComboBox otomatik günceller — kod tarafında ekstra
  bir şey yapmana gerek yok.
- ComboBox açılır listesi: native ok yerine özel `▾` karakteri
  kullanılıyor, açılan liste keskin kenarlıklı (1px border), native
  chrome yok.

**(b) Sohbet transkripti** (esnek yükseklik, kalan tüm dikey alanı kaplar):
- Kaydırılabilir (`ScrollViewer`), ince (6px) kaydırma çubuğu.
- Her mesaj: maksimum genişlik 760px, alt boşluk 28px.
- **Kullanıcı mesajları sağa hizalı**, **model mesajları sola hizalı**
  (`HorizontalAlignment` binding'i `IsUserMessage` bool değerine göre).
- Her mesaj İKİ satırdan oluşur:
  1. Rol etiketi ("Sen"/"You", "MarathonAI", "Hata"/"Error",
     "Uyarı"/"Warning", "Sistem"/"System") — `EyebrowTextStyle`: küçük
     punto, büyük harf değil ama düşük opaklık (~%55), alt boşluk 8px.
  2. Mesaj içeriği — `BodyTextStyle`: normal punto, tam opaklık,
     satır kırma açık (`TextWrapping="Wrap"`).
- **KESİNLİKLE chat-bubble/balon YOK.** Arka plan rengi, köşeli kutu,
  gölge yok. Sadece hizalama ve tipografiyle ayrışıyorlar.

**(c) Giriş şeridi** (üst boşluk 20px):
- 2 sütunlu Grid: [esnek genişlikte TextBox] [sabit genişlikte Buton]
- TextBox: tek satır görünümlü ama `TextWrapping="Wrap"` (görsel olarak
  büyürse çok satırlı gösterebilir), **sadece alt kenarlıkta 1px
  çizgi** (üst/sol/sağ kenarlık yok), şeffaf arka plan.
- Buton: "GÖNDER" (TR) / "SEND" (EN), sol marjı 16px.
- Enter tuşuna basınca mesaj gönderilir (TextBox'ta `KeyDown` handler'ı
  var, çok satırlı giriş için Shift+Enter gibi bir kombinasyon YOK,
  bunu eklemek istersen ayrı bir görev olarak ele al).

---

## 2. MEVCUT EKRAN DÖKÜMÜ — Ayarlar Penceresi (`SettingsWindow.xaml`)

Pencere: 480×680px, yeniden boyutlandırılamaz (`ResizeMode="NoResize"`),
ana pencerenin ortasında açılır (`WindowStartupLocation="CenterOwner"`).
İçerik kaydırılabilir (`ScrollViewer`), dış kenar boşluğu 32px sol/sağ,
32px üst, 28px alt.

Dikey sırayla (üstten alta), her bölüm arası **1px, %12 opaklık yatay
ayraç çizgisi + 28px boşluk**:

1. **Başlık:** "AYARLAR" / "SETTINGS" — `DisplayTextStyle`, alt boşluk 32px.
2. **Dil bölümü:**
   - Etiket: "Dil" / "Language" — `EyebrowTextStyle`, alt boşluk 10px.
   - ComboBox, genişlik 220px, sola hizalı. Seçenekler: "Türkçe",
     "English".
3. **Tema bölümü:**
   - Etiket: "Tema" / "Theme" — `EyebrowTextStyle`, alt boşluk 10px.
   - Yatay 2 RadioButton: "Koyu"/"Dark" (sağ marjı 32px), "Açık"/"Light".
     Kare çerçeveli işaretçi (native yuvarlak radyo DEĞİL).
4. **Dosya sistemi erişimi bölümü:**
   - Etiket: "Dosya Sistemi Erişimi" / "File System Access" —
     `EyebrowTextStyle`, alt boşluk 10px.
   - CheckBox: "AI'nin bilgisayarıma erişimine izin ver" / "Allow AI to
     access my computer" — alt boşluk 20px.
   - Etiket: "Yasaklı Klasörler" / "Blocked Folders" — alt boşluk 6px.
   - İpucu metni (küçük punto, %60 opaklık): "AI bu klasörlere ve alt
     klasörlerine asla erişemez, erişim açık olsa bile." — alt boşluk 14px.
   - **Klasör listesi:** her satır bir `Border` (alt kenarlıkta 1px
     çizgi, dikey 10px padding), içinde 2 sütunlu Grid: [klasör yolu
     metni, kırpılabilir] [küçük "Kaldır"/"Remove" butonu, sessiz/opak
     stil (`GhostButtonStyle`)]. Liste boşsa "Henüz yasaklı klasör
     eklenmedi." / "No blocked folders added yet." metni gösterilir.
   - "+ KLASÖR EKLE" / "+ ADD FOLDER" butonu, sola hizalı, üst boşluk 12px
     — tıklanınca native Windows klasör seçici açılır
     (`Microsoft.Win32.OpenFolderDialog`).
5. **API Anahtarları bölümü:**
   - Etiket: "API Anahtarları" / "API Keys" — `EyebrowTextStyle`.
   - Her sağlayıcı (Groq, OpenAI, Mistral) VE Tavily (web araştırma
     servisi) için: etiket ("Groq API Anahtarı" gibi, `EyebrowTextStyle`)
     + `PasswordBox` (şifreli görünüm, sadece alt kenarlıkta 1px çizgi).
     İlk alanın üst boşluğu 8px, sonrakiler 20px.
   - **ÖNEMLİ:** Bu alanlar SAĞLAYICI bazlıdır, MODEL bazlı değil — yani
     Groq'un 2 modeli olsa da tek bir "Groq API Anahtarı" alanı
     gösterilir (`ProviderRegistry.DistinctApiKeyProviders`).
6. **Alt satır:** Sağa hizalı, yatay: durum metni (küçük, %55 opaklık,
   boş başlar, kaydedince "Kaydedildi."/"Saved." yazar) + "KAYDET"/"SAVE"
   butonu.

---

## 3. TASARIM SİSTEMİ (KESİNLİKLE KORUNMALI)

### 3.1 Renk
- **Tam siyah-beyaz.** Gri ton YOK. Vurgu rengi (mavi, kırmızı vb.) YOK.
- Koyu tema: arka plan `#000000`, yazı `#FFFFFF`.
- Açık tema: arka plan `#FFFFFF`, yazı `#000000`.
- Kod: `Themes/Colors.Dark.xaml`, `Themes/Colors.Light.xaml` — sadece
  3 renk kaynağı tanımlı: `BackgroundBrush`, `ForegroundBrush`,
  `BorderBrush`. `ThemeManager.cs` çalışma zamanında ikisi arasında
  geçiş yapıyor (`DynamicResource` kullanımı sayesinde anında).

### 3.2 Tipografi
- **Font: Space Grotesk** (`Assets/Fonts/*.ttf`, SIL Open Font License).
  Referans: `./Assets/Fonts/#Space Grotesk` (göreli pack URI).
  Yüklenemezse WPF otomatik sistem fontuna düşer, sorun değil.
- 3 metin stili (`Themes/Styles.xaml`'da tanımlı), YENİ metin
  ekliyorsan bunlardan birini kullan, yenisini icat etme:
  - `DisplayTextStyle`: Bold + İtalik, büyük punto (32px) — başlıklar.
  - `EyebrowTextStyle`: Regular, küçük punto (12px), %55 opaklık —
    etiketler, kategori başlıkları.
  - `BodyTextStyle`: Regular, orta punto (15px), tam opaklık, 24px
    satır yüksekliği — gövde metni.

### 3.3 Kontroller
Tüm native WPF görünümü kaldırıldı, özel `ControlTemplate` kullanılıyor
(`Themes/Styles.xaml` içinde hepsi tanımlı):
- **Keskin köşe** — `CornerRadius` hiçbir yerde yok.
- **1px kenarlık** (`HairlineThickness` kaynağı).
- **Button:** Şeffaf zemin + 1px kenarlık; hover'da renk TAM TERSİNE
  döner (koyu temada: zemin beyaz, yazı siyah olur).
- **ComboBox:** Özel `▾` karakteri, keskin kenarlıklı açılır liste.
- **RadioButton/CheckBox:** Kare çerçeve + kare dolgu (native
  yuvarlak/tik YOK).
- **TabControl:** Alt çizgili minimalist sekme (klasik "kutu" sekme
  DEĞİL), seçili sekme 2px kalın alt çizgiyle vurgulanır.
- **ScrollBar:** İnce (6px), sadece thumb görünür, track yok.
- **GhostButtonStyle:** Kenarlıksız, düşük opaklı (%50), hover'da tam
  opaklık — "Kaldır" gibi ikincil eylemler için.

---

## 4. KRİTİK TEKNİK UYARI

Bu projede daha önce ciddi bir hata yaşandı: özel `ControlTemplate`
içindeki `ContentPresenter` elemanları `Foreground` rengini miras
almıyordu, bu yüzden buton/sekme/dropdown metinleri **tamamen görünmez**
oluyordu (arka planla aynı renkte render oluyordu). Düzeltme: her
`ContentPresenter`'a mutlaka
`TextElement.Foreground="{TemplateBinding Foreground}"` (veya duruma
göre `{DynamicResource ForegroundBrush}`) eklendi.

**Yeni bir `ControlTemplate` yazarsan bunu MUTLAKA ekle.** Kontrol et:
her `<ContentPresenter ...>` etiketinde `TextElement.Foreground` var mı.

---

## 5. YERELLEŞTİRME KURALI

Sabit metinleri asla doğrudan XAML'a yazma. Tüm kullanıcıya görünen
metinler `Resources/Lang/tr.json` ve `Resources/Lang/en.json`
dosyalarında bir anahtar olarak tanımlı, XAML'da şöyle bağlanıyor:

```xml
Text="{Binding T[AnahtarAdı], Source={x:Static loc:LocalizationManager.Instance}}"
```

Yeni bir metin eklersen, **her iki JSON dosyasına da** karşılığını
eklemeyi unutma, aksi halde o dilde anahtar adının kendisi (örn.
"NewFeatureLabel") görünür.

---

## 6. DOSYA YAPISI (referans)

```
src/MarathonAI/
├── MainWindow.xaml(.cs)          # Yukarıda tarif edilen ana pencere
├── SettingsWindow.xaml(.cs)      # Yukarıda tarif edilen ayarlar penceresi
├── Themes/
│   ├── Styles.xaml               # TÜM kontrol şablonları + metin stilleri burada
│   ├── Colors.Dark.xaml
│   └── Colors.Light.xaml
├── Resources/Lang/{tr,en}.json   # Tüm metinler
├── UI/
│   ├── ChatTab.cs                # Sekme durumu: Messages, SelectedProvider, ToolsEnabled
│   ├── ChatMessage.cs            # Mesaj modeli + MessageRole enum + IsUserMessage
│   └── BoolToAlignmentConverter.cs
└── Core/Api/ProviderRegistry.cs  # Sağlayıcı+model listesi (ComboBox'ın veri kaynağı)
```

---

## 7. SENDEN İSTENEN GÖREV

**[BURAYA SPESİFİK GÖREVİNİ YAZ — örnek:]**

> Sekme başlıklarının yanına küçük bir "×" kapatma butonu ekle.
> `GhostButtonStyle` kullan, 16×16px civarı, sekme metninin hemen
> sağında, 8px boşlukla. En az 1 sekme her zaman açık kalmalı — son
> sekmeyi kapatma denemesi görmezden gelinmeli.

Görevi tamamladıktan sonra, yukarıdaki Bölüm 1-2'deki dökümle
**tutarlı** kaldığını (yeni eklenen eleman dışında hiçbir konum/boyut/
metin değişmediğini) doğrula. Mümkünse gerçek ekran görüntüsüyle kontrol
et — bu proje "kod derlenir görünüyor ama gerçek cihazda render bozuk"
sorununu daha önce yaşadı, görsel doğrulama olmadan "tamamlandı" deme.
