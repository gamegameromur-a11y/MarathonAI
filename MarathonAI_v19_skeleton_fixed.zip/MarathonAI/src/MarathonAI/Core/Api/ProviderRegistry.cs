using System.Linq;

namespace MarathonAI.Core.Api;

/// <summary>
/// Kullanılabilir bir sağlayıcı + model kombinasyonunu tanımlar. Aynı
/// sağlayıcının (örn. OpenAI) birden fazla modeli (gpt-4o, gpt-4o-mini
/// gibi) ayrı ayrı seçenek olarak listelenir — kullanıcı "OpenAI"yi
/// değil, doğrudan "OpenAI — GPT-4o" gibi somut bir modeli seçer. Bu,
/// "aynı sağlayıcı içinde farklı model seçme" ihtiyacını karşılar
/// (örn. daha hızlı/ucuz bir model yerine daha güçlü bir model tercih
/// etmek).
///
/// Id: bu spesifik model seçeneğinin benzersiz kimliği (örn.
/// "openai-gpt-4o") — sekme durumunu, ComboBox seçimini vb. takip etmek
/// için kullanılır.
/// ApiKeyProviderId: hangi API anahtarının kullanılacağını belirtir
/// (örn. "openai") — aynı sağlayıcının birden fazla modeli AYNI
/// ApiKeyProviderId'yi paylaşır, böylece Ayarlar penceresinde her model
/// için değil, her SAĞLAYICI için tek bir anahtar alanı gösterilir
/// (bkz. SettingsWindow.xaml.cs, BuildApiKeyFields).
/// </summary>
public sealed record ProviderInfo(string Id, string DisplayName, string ApiKeyProviderId, Func<IChatClient> CreateClient);

/// <summary>
/// Mod 1'de (Resmi API) desteklenen tüm sağlayıcı+model kombinasyonlarının
/// merkezi listesi. Yeni bir model eklemek (örn. aynı sağlayıcıdan farklı
/// bir model, ya da tamamen yeni bir sağlayıcı) istendiğinde tek
/// yapılması gereken:
///   1. Yeni bir sağlayıcıysa, IChatClient implementasyonu yazmak
///      (genelde OpenAiCompatibleChatClient'tan türeyerek, bkz.
///      GroqChatClient.cs). Var olan bir sağlayıcının başka modeliyse,
///      bu adım gerekmez.
///   2. Aşağıdaki listeye, model adını (Id/DisplayName) ve o modeli
///      kullanan CreateClient'i belirten bir satır eklemek.
/// Böylece hem MainWindow hem Ayarlar penceresi otomatik olarak yeni
/// model+sağlayıcı kombinasyonunu tanır — MarathonAI'nin "10+ AI" ve
/// "aynı sağlayıcıda farklı model seçme" hedeflerinin (bkz.
/// docs/MarathonAI_Plan.md, Bölüm 1 ve Bölüm 2) somut altyapısı budur.
/// </summary>
public static class ProviderRegistry
{
    public static IReadOnlyList<ProviderInfo> All { get; } = new List<ProviderInfo>
    {
        // --- Groq (ücretsiz tier, varsayılan sağlayıcı) ---
        new(
            Id: "groq-llama-3.3-70b",
            DisplayName: "Groq — Llama 3.3 70B (ücretsiz)",
            ApiKeyProviderId: "groq",
            CreateClient: () => new GroqChatClient(ApiKeyStore.GetGroqKey(), model: "llama-3.3-70b-versatile")
        ),
        new(
            Id: "groq-llama-3.1-8b",
            DisplayName: "Groq — Llama 3.1 8B (hızlı, ücretsiz)",
            ApiKeyProviderId: "groq",
            CreateClient: () => new GroqChatClient(ApiKeyStore.GetGroqKey(), model: "llama-3.1-8b-instant")
        ),

        // --- OpenAI ---
        new(
            Id: "openai-gpt-4o",
            DisplayName: "OpenAI — GPT-4o",
            ApiKeyProviderId: "openai",
            CreateClient: () => new OpenAiChatClient(ApiKeyStore.GetOpenAiKey(), model: "gpt-4o")
        ),
        new(
            Id: "openai-gpt-4o-mini",
            DisplayName: "OpenAI — GPT-4o mini",
            ApiKeyProviderId: "openai",
            CreateClient: () => new OpenAiChatClient(ApiKeyStore.GetOpenAiKey(), model: "gpt-4o-mini")
        ),

        // --- Mistral ---
        new(
            Id: "mistral-large",
            DisplayName: "Mistral — Large",
            ApiKeyProviderId: "mistral",
            CreateClient: () => new MistralChatClient(ApiKeyStore.GetMistralKey(), model: "mistral-large-latest")
        ),
        new(
            Id: "mistral-small",
            DisplayName: "Mistral — Small",
            ApiKeyProviderId: "mistral",
            CreateClient: () => new MistralChatClient(ApiKeyStore.GetMistralKey(), model: "mistral-small-latest")
        ),
    };

    /// <summary>
    /// Ayarlar penceresinde "her sağlayıcı için tek key alanı" göstermek
    /// amacıyla, All listesini ApiKeyProviderId'ye göre tekilleştirilmiş
    /// (distinct) bir liste olarak sunar — her sağlayıcı ailesi (Groq,
    /// OpenAI, Mistral) sadece bir kez görünür, kaç modeli olursa olsun.
    /// </summary>
    public static IReadOnlyList<(string ApiKeyProviderId, string DisplayName)> DistinctApiKeyProviders =>
        All
            .GroupBy(p => p.ApiKeyProviderId)
            .Select(g => (g.Key, DisplayName: g.Key switch
            {
                "groq" => "Groq",
                "openai" => "OpenAI",
                "mistral" => "Mistral",
                _ => g.Key
            }))
            .ToList();

    /// <summary>
    /// Varsayılan sağlayıcı+model: Groq Llama 3.3 70B. Sebep: kullanıcının
    /// kendi API anahtarı olmasa bile Groq'un ücretsiz tier'ı üzerinden
    /// uygulamayı hemen deneyebilmesi hedefleniyor (bkz.
    /// docs/MarathonAI_Plan.md, Bölüm 1).
    /// </summary>
    public static ProviderInfo Default => All[0];

    public static ProviderInfo? FindById(string id) => All.FirstOrDefault(p => p.Id == id);
}
