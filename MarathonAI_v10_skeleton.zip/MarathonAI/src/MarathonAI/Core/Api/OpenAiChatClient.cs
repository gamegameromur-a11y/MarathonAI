namespace MarathonAI.Core.Api;

/// <summary>
/// OpenAI Chat Completions API'sine bağlanan istemci (Mod 1 — Resmi API).
/// </summary>
public sealed class OpenAiChatClient : OpenAiCompatibleChatClient
{
    private const string ApiUrl = "https://api.openai.com/v1/chat/completions";
    private const string DefaultModel = "gpt-4o-mini";

    public OpenAiChatClient(string apiKey, string model = DefaultModel, System.Net.Http.HttpClient? httpClient = null)
        : base("OpenAI", ApiUrl, apiKey, model, httpClient)
    {
    }
}
