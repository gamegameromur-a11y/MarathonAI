using System.Linq;
using System.Text.Json;
using MarathonAI.Core.Api;

namespace MarathonAI.Core.Tools;

/// <summary>
/// MarathonAI'nin kendi "derin araştırma" aracı (bkz.
/// docs/MarathonAI_Plan.md, Bölüm 4 ve 6.6 — "platformların native
/// deep research özelliğine ek/alternatif, MarathonAI'nin kendi
/// versiyonu").
///
/// Fark, basit WebSearchTool'dan şu şekilde: WebSearchTool tek bir arama
/// sorgusu çalıştırıp ham sonuçları döner — modelin kendisi, konuyu
/// derinlemesine araştırmak isterse WebSearchTool'u ToolCallingLoop
/// içinde defalarca çağırabilir (bu zaten mümkün). DeepResearchTool ise
/// TEK BİR araç çağrısında, kendi içinde birden fazla alt-sorguyu
/// PARALEL olarak çalıştırıp sonuçları birleştirir — bu hem daha hızlı
/// (paralel istekler, tek tek sıralı tur beklemek yerine) hem de
/// modelin "önce şunu arayayım, sonra bunu arayayım" diye ayrı ayrı
/// tur harcamasını önler.
///
/// Alt-sorgu üretimi şimdilik basit bir sezgisel yöntemle yapılıyor
/// (ana sorgu + birkaç varyasyon); ileride bu, modelin kendisine
/// "bu konu için hangi alt-sorguları araştırmalıyım" diye sorulup
/// üretilen daha akıllı bir plana dönüştürülebilir.
/// </summary>
public sealed class DeepResearchTool : IToolHandler
{
    private const int MaxSubQueries = 4;

    public ToolDefinition Definition { get; } = new(
        Name: "deep_research",
        Description: "Bir konuyu birden fazla açıdan (farklı alt-sorgularla) derinlemesine araştırır ve " +
                     "sonuçları birleştirip döner. Basit tek bir soru için web_search yeterlidir; bu araç " +
                     "karmaşık, çok yönlü konular için kullanılmalıdır.",
        ParametersJsonSchema: """
        {
          "type": "object",
          "properties": {
            "topic": {
              "type": "string",
              "description": "Derinlemesine araştırılacak ana konu/soru"
            },
            "subQueries": {
              "type": "array",
              "items": { "type": "string" },
              "description": "Konuyu farklı açılardan araştırmak için 2-4 arası alt-sorgu. " +
                              "Her biri ana konunun farklı bir yönünü ele almalı."
            }
          },
          "required": ["topic", "subQueries"]
        }
        """);

    private readonly WebSearchTool _webSearchTool = new();

    public async Task<string> ExecuteAsync(string argumentsJson, CancellationToken cancellationToken = default)
    {
        string? topic;
        List<string> subQueries;

        try
        {
            using var doc = JsonDocument.Parse(argumentsJson);
            topic = doc.RootElement.GetProperty("topic").GetString();
            subQueries = doc.RootElement.GetProperty("subQueries")
                .EnumerateArray()
                .Select(e => e.GetString())
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .Cast<string>()
                .Take(MaxSubQueries)
                .ToList();
        }
        catch (Exception)
        {
            return BuildErrorResult("Geçersiz araç parametresi (topic/subQueries okunamadı).");
        }

        if (string.IsNullOrWhiteSpace(topic) || subQueries.Count == 0)
        {
            return BuildErrorResult("Konu ve en az bir alt-sorgu gereklidir.");
        }

        // Tavily key kontrolü burada, tek seferde yapılıyor — aksi
        // halde her alt-sorgu WebSearchTool içinde ayrı ayrı aynı hatayı
        // üretir (4 paralel istek, 4 özdeş hata mesajı), bu gereksiz.
        if (string.IsNullOrWhiteSpace(ApiKeyStore.GetTavilyKey()))
        {
            return BuildErrorResult(
                "Derin araştırma aracı için API anahtarı bulunamadı. Kullanıcıya, Ayarlar " +
                "penceresinden Tavily API anahtarını girmesi gerektiğini söyle " +
                "(tavily.com üzerinden ücretsiz alınabilir).");
        }

        // Tüm alt-sorgular PARALEL olarak çalıştırılıyor — sıralı 4 arama
        // yerine tek bir bekleme süresinde hepsi tamamlanıyor. Bu, Bölüm
        // 1'deki "hız" marka değeriyle doğrudan uyumlu.
        var searchTasks = subQueries.Select(async subQuery =>
        {
            var argsForSubQuery = JsonSerializer.Serialize(new { query = subQuery });
            var resultJson = await _webSearchTool.ExecuteAsync(argsForSubQuery, cancellationToken);
            return new { subQuery, resultJson };
        });

        var results = await Task.WhenAll(searchTasks);

        var combined = new
        {
            topic,
            subQueryResults = results.Select(r => new
            {
                query = r.subQuery,
                results = TryParseAsJsonElement(r.resultJson)
            })
        };

        return JsonSerializer.Serialize(combined);
    }

    private static object TryParseAsJsonElement(string json)
    {
        try
        {
            return JsonSerializer.Deserialize<JsonElement>(json);
        }
        catch (Exception)
        {
            return new { error = "Alt-sorgu sonucu ayrıştırılamadı." };
        }
    }

    private static string BuildErrorResult(string message) =>
        JsonSerializer.Serialize(new { success = false, error = message });
}
