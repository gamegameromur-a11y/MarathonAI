namespace MarathonAI.Core.Api;

/// <summary>
/// API isteğine gönderilecek tek bir konuşma turu. UI katmanındaki
/// MarathonAI.UI.ChatMessage'dan (Role artık dilden bağımsız bir enum:
/// MessageRole — bkz. UI/ChatMessage.cs) kasıtlı olarak ayrı tutuluyor —
/// burada Role API'nin beklediği sabit değerlerden biri olmalı: "user"
/// veya "assistant" ("system" ileride system prompt desteği
/// eklendiğinde kullanılacak, bkz. docs/MarathonAI_Plan.md Bölüm 4).
/// </summary>
public sealed record ApiChatMessage(string Role, string Content)
{
    public static ApiChatMessage User(string content) => new("user", content);
    public static ApiChatMessage Assistant(string content) => new("assistant", content);
}
