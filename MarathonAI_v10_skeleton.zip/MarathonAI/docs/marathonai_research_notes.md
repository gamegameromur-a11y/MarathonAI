# MarathonAI — Referans Araştırma Notları
## Kaynak: AI-UX-Customizer (p65536/AI-UX-Customizer, GitHub)

Bu proje, ChatGPT ve Gemini'nin web arayüzünü Tampermonkey userscript'i ile
temalayan, MIT lisanslı, açık kaynak bir araç. Senin "kullanıcı gerçek input'a
kendi eliyle yazıyor, biz sadece görsel katmanı değiştiriyoruz" (Senaryo A)
yaklaşımının gerçek dünyada çalışan bir örneği. MarathonAI için doğrudan
uygulanabilir bir mimari şablon sunuyor.

---

## 1. Genel Mimari

- **Tek dosya, tek script**, `@match` direktifiyle hangi URL'lerde çalışacağı
  tanımlanıyor (`chatgpt.com/*`, `gemini.google.com/*`).
- `document-start` aşamasında devreye giriyor (sayfa daha yüklenmeden önce),
  böylece kullanıcı orijinal (temasız) arayüzü hiç görmüyor.
- Hostname'e bakarak hangi platformda olduğunu tespit ediyor:

```js
const PLATFORM_DEFS = {
  CHATGPT: { NAME: 'ChatGPT', HOST: 'chatgpt.com' },
  GEMINI:  { NAME: 'Gemini',  HOST: 'gemini.google.com' },
};

function identifyPlatform() {
  const hostname = window.location.hostname;
  if (hostname.endsWith(PLATFORM_DEFS.CHATGPT.HOST)) return PLATFORM_DEFS.CHATGPT.NAME;
  if (hostname.endsWith(PLATFORM_DEFS.GEMINI.HOST)) return PLATFORM_DEFS.GEMINI.NAME;
  return null;
}
```

**MarathonAI için:** Bu yapı, WebView2/CEF içinde "hangi sekmede hangi adaptörü
çalıştıracağız" kararını vermek için birebir kullanılabilir.

---

## 2. Selector Yönetimi (En Kritik Kısım)

Tüm CSS selector'lar **tek bir merkezi obje** içinde toplanmış:
`CONSTANTS.SELECTORS`. Kodun geri kalanı asla ham selector string'i yazmıyor,
hep bu objeye referans veriyor. Örnek kategoriler (ChatGPT için):

| Kategori | Anlamı |
|---|---|
| `MAIN_APP_CONTAINER` | Ana uygulama kapsayıcısı |
| `CONVERSATION_UNIT` | Bir sohbet "turn"unun kapsayıcısı |
| `USER_MESSAGE` / `ASSISTANT_MESSAGE` | Kullanıcı/asistan mesaj kapsayıcıları |
| `INPUT_TEXT_FIELD_TARGET` | Gerçek yazma alanı (input kutusu) |
| `INPUT_RESIZE_TARGET` | Input formunun kendisi (gönderme dahil) |
| `INSERTION_ANCHOR` | Kendi butonlarımızı eklemek için referans nokta |
| `AVATAR_USER` / `AVATAR_ASSISTANT` | Avatar alanları |
| `SCROLL_CONTAINER` | Kaydırma konteyneri |
| `CANVAS_CONTAINER` | Canvas/özel görünüm alanı |

**Önemli mühendislik notu (dosyanın kendi yorumu):**
> Dinamik olarak parent selector olarak birleştirilecek selector'larda
> virgülle ayrılmış liste (`'A, B'`) KULLANMA — CSS scope'unu bozar.
> Bunun yerine `:is(A, B)` kullan.

**MarathonAI için:** Her AI sitesi (ChatGPT, Claude, Gemini, GLM, Mistral) için
ayrı bir `SELECTORS` bloğu tanımlanmalı. Bu, adaptör yazma sürecinin ana
iskeleti olacak — DOM envanterinden çıkardığımız elementler bu tabloya
oturtulacak.

---

## 3. Tema/CSS Enjeksiyon Mantığı

- Selector'lara dayanarak dinamik olarak bir CSS string'i oluşturuluyor ve
  sayfaya `<style>` etiketi olarak enjekte ediliyor.
- Örnek desen: `${CONSTANTS.SELECTORS.USER_MESSAGE} ${CONSTANTS.SELECTORS.RAW_USER_BUBBLE} { ... }`
  şeklinde selector'lar birleştirilerek CSS kuralları üretiliyor.

**MarathonAI için:** Bu, "ortak tasarım sistemi + platforma özel selector
haritası" ayrımını doğruluyor — tam olarak konuştuğumuz yaklaşım.

---

## 4. Ayarların Saklanması

- `GM.setValue` / `GM.getValue` (Tampermonkey'in kendi storage API'si)
  kullanılıyor — kullanıcı ayarları (tema, renkler vb.) tarayıcı içinde
  saklanıyor.

**MarathonAI için:** Bizim durumumuzda bu, uygulamanın kendi local
storage'ı (SQLite / JSON dosyası / Windows registry) olacak, WebView2'nin
`ExecuteScriptAsync` ile JS enjekte edip sonucu C++ tarafına aktarabiliriz.

---

## 5. Riskler / Doğrulanan Endişeler

- Proje **düzenli güncelleniyor** (changelog'da neredeyse haftalık sürüm
  artışları var) — bu, "sitelerin arayüzü değiştikçe adaptör kodu bozulur,
  sürekli bakım gerekir" öngörümüzü doğruluyor.
- Proje sadece **masaüstü tarayıcıları** hedefliyor, mobil desteklemiyor —
  bizim de Windows masaüstü odaklı olmamızla uyumlu.
- Proje 2 platform (ChatGPT, Gemini) için bile devasa bir dosya (21,700+
  satır) gerektirmiş — 5 platform için bu iş, tahmin ettiğimizden daha büyük
  bir mühendislik yükü olabilir. Kapsamı MVP'de daraltmayı düşünmeliyiz.

---

## 6. MarathonAI'ye Uygulama Planı (Sonraki Adım)

1. DOM envanterini (manuel DevTools ile veya benzer bir araçla) her 5 site
   için çıkar.
2. Bu envanterden, yukarıdaki tabloya benzer bir `SELECTORS` haritası
   oluştur (her site için ayrı).
3. WebView2 içinde `NavigationCompleted` event'inde ilgili platformun JS
   adaptörünü `ExecuteScriptAsync` ile enjekte et.
4. Ortak tema CSS'ini (renkler, fontlar, layout) tek yerde tanımla, her
   adaptör kendi selector'larıyla bu ortak temayı uygula.
