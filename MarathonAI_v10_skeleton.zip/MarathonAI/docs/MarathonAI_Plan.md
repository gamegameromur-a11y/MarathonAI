# MarathonAI — Proje Planı ve Referans Dokümanı

> Bu doküman, planlama sohbetinde konuşulan her şeyin özetidir. Kod yazarken
> bir şey unutulursa buraya bakılacak. **Statüs: Alpha / erken plan aşaması.**
> Kod yazımına henüz başlanmadı — proje sahibi net "başla" demeden kod
> yazılmayacak.

---

## 1. Ürün Vizyonu

MarathonAI, birden fazla AI modelini (ChatGPT, Claude, Gemini, GLM, Mistral
ve daha fazlası) **tek bir Windows masaüstü uygulaması** altında toplayan bir
araç. Amaç: kullanıcıların, hangi AI sağlayıcısını kullanırlarsa kullansınlar,
tutarlı, hızlı, premium bir arayüzden erişebilmeleri — hem ücretsiz/düşük
maliyetli hem de gelişmiş agent/otomasyon özellikleriyle.

**Marka kimliği:** Hız. Üç modda da (API, Web, Local) agresif optimizasyon
hedefleniyor — MarathonAI'nin ayırt edici özelliği bu olacak.

**Tasarım dili:** Siyah-beyaz, premium/sade görünüm. Detaylar için Bölüm 10.1.

---

## 2. Temel Mimari — 3 Çalışma Modu

MarathonAI üç ayrı "motor" ile çalışacak. Bunlar kullanıcı tarafından
seçilebilir/karışık kullanılabilir.

### Mod 1 — Resmi API
- Kullanıcının kendi API key'i (OpenAI, Anthropic, Google, Mistral, vs.) ile
  veya OpenRouter gibi bir aracı katman üzerinden.
- **En yetkili mod:** tam tool-calling, system prompt, agent zincirleri,
  dosya işlemleri, sınırsız (ToS dahilinde) özellik desteği.
- OpenRouter gibi bir katman kullanılırsa **20+ model** tek entegrasyonla
  desteklenebilir — projenin "10+ AI" hedefinin asıl gerçekleştiği yer burası.
- 3D model üretimi gibi harici uzman API'ler (Meshy, Tripo) de bu moda dahil.

### Mod 2 — Web Arayüzü (CSS Re-skin)
- Kullanıcı, gömülü bir Chromium tabanlı tarayıcı motoru (WebView2 önerilir)
  içinde **gerçek** AI web sitesine (chatgpt.com, gemini.google.com) **kendi
  hesabıyla** giriş yapar.
- **KRİTİK KURAL — asla değişmez:** Kullanıcının fiziksel olarak tıkladığı ve
  yazdığı input kutusu, o sitenin **gerçek DOM elementidir**. CSS/JS
  enjeksiyonu ile sadece görsel katman (renk, font, layout, ikonlar)
  MarathonAI temasına "giydirilir" — hiçbir otomasyon (kod ile input'a metin
  yazma, kod ile gönder butonuna basma, panoya yazıp otomatik yapıştırma,
  network isteğine müdahale) YAPILMAZ. Bu, üçüncü taraf sitelerin kullanım
  şartlarını (ToS) ihlal etmemek için değişmez bir sınırdır.
- **Referans proje:** [AI-UX-Customizer](https://github.com/p65536/AI-UX-Customizer)
  (MIT lisans) — ChatGPT ve Gemini için CSS re-skin yapan, aynı prensiple
  çalışan açık kaynak bir userscript. Selector haritalama ve CSS enjeksiyon
  mimarisi için doğrudan referans alınacak (bkz. `marathonai_research_notes.md`).
- **MVP platform kapsamı: sadece ChatGPT + Gemini** (referans proje de bu
  ikisini kapsıyor, işi kolaylaştırıyor).
- **Opsiyonel system prompt (gizli değil):** Sohbet başında kullanıcıya
  "önerilen system prompt" bir **bildirim** olarak gösterilir (tüm ekranı
  kaplamaz). Kullanıcı isterse kopyalayıp kendi eliyle yapıştırır, istemezse
  yok sayar — **zorunlu değildir.** Her ~40 mesajda bir nazikçe hatırlatılır,
  ama zorlanmaz. Prompt her seferinde değişebilir/güncellenebilir ama her
  zaman kullanıcıya görünür şekilde sunulur, asla gizlice enjekte edilmez.
- **Sürekli/otonom agent modu bu modda YOKTUR.** Bunun yerine "tek cevap
  içinde çok adımlı çalışma" desteklenir: model tek bir mesajda "Adım 1...
  Adım 2... Adım 3... Bitti" şeklinde uzun, çok parçalı bir cevap üretebilir.
  Bunun doğal sınırları vardır: model output token limiti ve gerçek zamanlı
  araç sonucu alamama (araç kullanımı gerektiren çok adımlı işler için Mod
  1/3 gereklidir). Bu bir sorun değil, kabul edilen bir sınırdır.
- Ses (STT/TTS) gibi özellikler, o sitenin **kendisinde** varsa (native),
  MarathonAI sadece görsel/izin katmanını yönetir (mikrofon izni WebView2
  üzerinden akar), otomasyon yapılmaz.

### Mod 3 — Local AI
- Hugging Face (ve benzeri platformlar) üzerinden açık kaynak modelleri
  **yerel** çalıştırma.
- Mod 1'in sahip olduğu tüm yeteneklere (tool-use, agent, dosya işlemleri)
  sahip olabilir çünkü tamamen MarathonAI'nin kendi kontrolündedir.
- **Hız/optimizasyon önceliği:** Modeller belirli kuantizasyon seviyelerinde
  (örn. 4-bit) ve hızlandırılmış çıkarım motorlarıyla (`llama.cpp`, `vLLM`,
  `ExLlamaV2`, GGUF/GPTQ/AWQ formatları gibi) çalıştırılacak. Kullanıcının
  donanımına göre otomatik motor/kuantizasyon seçimi hedeflenir.
- **3D üretim gibi özel model türleri** (örn. TRELLIS.2, MIT lisanslı; Mod
  1'de Meshy/Tripo gibi API'ler) bu modda desteklenebilir — donanım gücüne
  bağlı. Bu tür modeller için MarathonAI kendi **çalışma ortamını**
  hazırlar (gerekli bağımlılıklar, format dönüştürme) ve üretilen model
  sadece dosya olarak değil, kullanıcının döndürüp inceleyebileceği bir
  **3D görüntüleme alanı (viewer)** içinde de sunulur — sağ paneldeki
  dosya görüntüleme sisteminin 3D'ye özel bir genişlemesi.
- **Kapsam prensibi:** "Yapabildiğimiz kadar" — HF'teki her modeli değil, en
  çok talep edilen/popüler model tiplerinden başlayıp genişleyen,
  önceliklendirilmiş bir liste.

---

## 3. Otomasyon Sınırı — Değişmez Prensip

Bu proje boyunca defalarca test edilen ve her seferinde aynı sonuca varılan
kural, net olarak buraya yazılmalı:

> **Web arayüzü (Mod 2) üzerinden çalışan hiçbir özellik, kod tarafından
> otomatik olarak bir input'a metin yazamaz veya bir gönder/submit eylemini
> tetikleyemez.** Bu, klavye simülasyonu, pano üzerinden otomatik yapıştırma,
> network isteğine müdahale gibi hiçbir teknik varyasyonla aşılamaz.
> Kullanıcının onayı/rızası bile bu kısıtlamayı değiştirmez, çünkü mesele
> rıza değil, üçüncü taraf sitenin ToS'unu otomasyon yoluyla ihlal etmemektir.
>
> Buna karşılık: **Mod 1 (resmi API) ve Mod 3 (local model), bu kısıtlamaya
> tabi değildir** çünkü bunlar sağlayıcının kendi izin verdiği, resmi
> entegrasyon yollarıdır (API) veya tamamen MarathonAI'nin kendi kontrolünde
> çalışan sistemlerdir (local).
>
> Sonuç: **Otomasyon/agent/sürekli-çalışma gerektiren her özellik Mod 1 veya
> Mod 3'e yönlendirilir. Mod 2 sadece "kullanıcı kendi eliyle kullanıyor,
> görsel katman değişti" sınırında kalır.**

---

## 4. Genel Arayüz Özellikleri

- Sol panel: önceki sohbetler (sohbet geçmişi listesi).
- Sağ panel: model tarafından oluşturulan dosyaları görüntüleme/düzenleme;
  kullanıcı değişiklik yapıp tekrar modele gönderebilir.
- Sohbet içinde model değiştirme (tüm modeller arasında, sohbeti bozmadan).
- Modelin oluşturduğu dosyalar kullanıcıya **metin olarak değil, dosya
  olarak** teslim edilir (her AI'nin dosya kabul etme özelliği olduğu
  varsayımıyla).
- Kendi web araştırma aracımız: model bunu kullandığında ham çıktı
  (kirlilik) kullanıcıya gösterilmez, MarathonAI arayüzü bunu temizleyip
  sunar.
- Sesli konuşma/ses tanıma: hangi model/platformda native olarak varsa,
  MarathonAI da destekler (Mod 2'de sitenin kendi altyapısı + görsel re-skin;
  Mod 1/3'te ayrı STT/TTS entegrasyonu gerekir).
- Model/platform özel yetenekler (şarkı üretme, video üretme, görsel üretme
  vb.) **mümkün olduğunca geniş** desteklenir — sabit değil, zamanla
  genişleyen, önceliklendirilmiş bir yol haritası.
- **Düşünme/reasoning modları:** Modellerin "düşünme" (extended thinking),
  efor seviyesi (low/high reasoning effort) ve derin araştırma (deep
  research) gibi modları özenle desteklenecek.
  - Mod 2'de: o platformun kendi arayüzünde bu bir seçenek/düğme olarak
    varsa, bulunup temaya uydurulur, kullanıcı kendi eliyle seçer.
  - Mod 1'de: sağlayıcının API'sindeki ilgili parametre (örn. reasoning
    effort, thinking budget) kullanılır — standart entegrasyon.
  - Mod 3'te: açık kaynak "reasoning" modellerinin (örn. DeepSeek-R1 tarzı)
    ürettiği düşünme sürecinin çıktıdan ayrıştırılıp düzenli gösterilmesi
    gerekir.
  - **Ayrıca MarathonAI'nin kendi versiyonları da olacak:** Platformun
    sunduğu native özelliğin yanı sıra, MarathonAI kendi "derin araştırma"
    ve "düşünme/planlama" katmanını da geliştirecek (kendi web araştırma
    aracımız gibi). Bu, özellikle bir platformun bu özelliği native olarak
    sunmadığı durumlarda (örn. bazı Mod 2 platformlarında) boşluğu
    dolduracak; platformun kendi özelliği ile MarathonAI'nin kendi
    versiyonu kullanıcıya ayrı seçenekler olarak sunulabilir.

---

## 5. Ayarlar Menüsü

- **Dil desteği:** 26 dile kadar.
- **Tema:** Koyu / Açık tema seçimi (bkz. Bölüm 10.1).
- **Dosya sistemi erişimi:** AI'ın kullanıcının bilgisayarına erişimini
  açma/kapama, erişim derecesini sınırlama, belirli klasörleri "AI giremez"
  olarak işaretleme (sandbox/izin listesi mantığı).
- **Varsayılan model:** Her yeni sohbette otomatik seçilecek model.
- **İnternet erişim kısıtlaması:** Modelin internette ne kadar "açık"
  olacağı — belirli siteleri açma/kapama, "sadece okuma" modu (yazma
  kapatılabilir).
- **Özel system prompt:** Kullanıcının kendi tanımladığı kalıcı talimat.
- **Sohbet dışa/içe aktarma:** Belirli bir sohbeti dışa aktarabilme; başka
  bir cihazdan/kaynaktan bir sohbeti içe aktarıp kaldığı yerden devam
  edebilme.
- **Kullanım kılavuzu:** Uygulama içi kısa "nasıl kullanılır" notu.

---

## 6. Gelişmiş Modlar

### 6.1 Design Modu
Claude'un Artifacts'ine benzer — HTML'in ötesine geçen, daha detaylı görsel/
arayüz üretimi yapabilen bir çalışma modu. Normal modellerin bile
kullanabileceği bir yetenek katmanı olarak sunulacak.

### 6.2 Agent Modu
- Kullanıcı bir "agent sekmesi" açtığında, birden fazla AI'yı birbirine
  bağlayabilir (3 modun herhangi birinde, örn. Mod 2'de GPT + Gemini
  birlikte çalışabilir).
- Her AI'ya ortak bir görev veya ayrı ayrı system prompt verilebilir, tek
  arayüzden kontrol edilir.
- **Hedefli mesajlaşma sözdizimi:** `/GPT-mesaj-/` gibi bir işaretleme ile,
  kullanıcı belirli bir mesajın sadece belirli bir AI'ya gitmesini
  sağlayabilir (diğer AI'lar görmez). İşaretlenmemiş mesajlar normalde tüm
  bağlı modellere gider.
- **Katmanlı iş akışı:** Kullanıcının prompt'u önce 1. katmana gider (temel
  yapıyı oluşturur, örn. yazılım projesinin iskeleti), sonraki katmanlar
  geliştirmeye devam eder, son katman(lar) test/doğrulama yapar.
- **Karma model türleri:** Agent modunda kullanıcı tek bir model türüyle
  (yalnızca metin üreten modellerle) sınırlı kalmaz. Farklı model türleri
  (metin, 3D model üretimi, görsel/asset üretimi, kod yazımı vb.) aynı
  agent zincirinde birlikte çalışabilir — örneğin bir model kodu yazarken,
  başka bir model o proje için 3D varlıklar üretebilir, bir başkası da bu
  varlıklara doku/asset hazırlayabilir. Katmanlı iş akışı (yukarıda) bu
  karma modelleri de kapsayacak şekilde tasarlanır.
- Agent'lara CMD gibi sistem erişim noktaları verilebilir.
- **Kod çalışma alanları:** C++, Python, Rust ortamları — agent sohbet
  başında hangisini kullanacağını seçer veya sohbet ilerlerken değiştirebilir;
  proje gerektiriyorsa üçünü birden de alabilir.
- **Plan/Build alt-modu:**
  - *Plan aşaması:* AI projenin temelini/mimarisini oluşturur, planı
    kullanıcıya sunar (kod yazmadan önce).
  - *Build aşaması:* Onaylanan plana göre ortamı kurar, kodu yazar, bitirir
    ve teslim eder.
  - Mobil uygulama geliştirmeyi de kapsar (Expo gibi araçlarla — ama **tek
    bir araca bağlı kalınmaz**, projenin ihtiyacına göre farklı framework/
    araç setleri kullanılabilir; Replit Agent benzeri bir deneyim
    hedeflenir).
  - Bu alt-mod, sürekli komut çalıştırma/dosya oluşturma gerektirdiği için
    esasen **Mod 1/3** ile çalışır; Mod 2'de doğası gereği sınırlı kalır.
- **"Süreklilik modu" (kesintisiz çalışma):** Kullanıcının mesaj yazma
  alanındaki model seçme kısmında küçük bir düğmeyle açılır. Bu modda model
  **tek bir cevap içinde** göreve ait tüm adımları sırayla üretir, iş
  bitince durur ("kullanıcıyı rahatsız etmeden" kendi kendine karar
  vererek ilerler) — bu, kodun modelin çıktısını okuyup otomatik yeni
  mesaj gönderdiği bir mekanizma DEĞİLDİR. Mod 1/3'te bu daha esnek/tam
  agent döngüsü olarak çalışabilir; Mod 2'de "tek cevap, çok adım" sınırına
  tabidir (bkz. Bölüm 3).

### 6.3 Kontrol Modu
- Kullanıcı bir işlemi yapamadığında AI'ya devreder, AI kullanıcının
  bilgisayarında kontrolü (fare/klavye benzeri) ele alıp o işlemi
  tamamlayabilir.
- **Acil durdurma:** Kullanıcı `Delete` tuşuna basarak bu süreci anında
  durdurabilir.
- **Güvenlik prensibi (değişmez):** Modelin kendi davranışsal sınırlarına
  ("kötü bir şey yapmam" demesine) güvenilmez. MarathonAI kendi **teknik**
  izin/sandbox katmanını kurar: hangi klasörlere erişilebilir, hangi
  komutlar çalıştırılabilir, hangi eylemler onay gerektirir, kaynak kullanım
  limitleri nedir — bunlar modelin "iyi niyetine" değil, sistemin teknik
  kısıtlamalarına dayanır. Sebep: modeller karmaşık görevlerde niyeti yanlış
  çıkarabilir, prompt injection ile kandırılabilir, ya da basitçe hata
  yapabilir.

### 6.4 Belirleme Modu
Kullanıcı bir AI'yı belirli bir üçüncü parti uygulamaya (örn. CapCut)
atayabilir; model o uygulamanın işlerini (örn. video düzenleme) yürütür.
Bu, işletim sistemi seviyesinde (resmi UI Automation / Accessibility API'leri
gibi) çalışan, web sitesi ToS'undan bağımsız ayrı bir teknik alan.

### 6.5 Agent'ların Donanım Erişimi
Agent modunda modeller, kendilerine verilen görev için kullanıcının
donanımını (CPU/GPU, disk vb.) kullanabilir. Kontrol Modu ve kod çalışma
alanlarıyla aynı güvenlik prensibine (Bölüm 6.3) tabidir — teknik
sandbox/izin sistemi şart.

### 6.6 MarathonAI Araç Kütüphanesi

Model tarafından çağrılabilen (tool-calling ile), standart girdi/çıktı
alışverişi yapan araçlar. Claude'un kendi araç setinden ilham alınarak,
MarathonAI'nin bağlamına uyarlanmış tam liste:

**Bilgi toplama:**
1. **Web araştırma aracı** — MarathonAI'nin kendi web arama motoru. Ham
   çıktı kullanıcıdan gizlenir, temiz/işlenmiş sonuç gösterilir (bkz.
   Bölüm 4).
2. **Sayfa içeriği çekme (web fetch)** — belirli bir URL'nin tam içeriğini
   getirme (arama sonucu özetinden daha detaylı, tam sayfa okuma).
3. **Görsel arama** — web üzerinde ilgili görselleri bulma.

**Dosya ve kod işlemleri:**
4. **Kod çalıştırma aracı (sandbox)** — C++/Python/Rust çalışma ortamları;
   model kod çalıştırabilir, sonucu alabilir (bkz. Bölüm 6.2).
5. **Dosya oluşturma aracı** — MarathonAI'nin kendi dosya oluşturucusu.
   Çıktı kullanıcıya metin olarak değil, dosya olarak sunulur; sağ panelde
   görüntülenip düzenlenebilir.
6. **Dosya görüntüleme/okuma aracı** — mevcut dosyaları/klasörleri
   inceleme (Kontrol Modu ve Agent Modu'nun dosya sistemi erişimiyle
   bağlantılı, bkz. Bölüm 6.3).
7. **Dosya içinde değişiklik yapma aracı** — var olan bir dosyada belirli
   bir kısmı bulup değiştirme (bulk rewrite yerine hedefli düzenleme).
8. **Dosyaları kullanıcıya sunma** — üretilen/değiştirilen dosyaların sağ
   panelde kullanıcıya net şekilde gösterilmesi.

**Görsel/arayüz üretimi:**
9. **Diyagram/görsel widget üretimi** — Design Modu kapsamında, model
   interaktif SVG/HTML görseller (diyagram, grafik, mockup, mini
   uygulama) üretebilir (bkz. Bölüm 6.1).

**Derin araştırma:**
10. **Derin araştırma aracı** — MarathonAI'nin kendi derin araştırma
    motoru (platformların native "deep research" özelliğine
    ek/alternatif, bkz. Bölüm 4).

**Dış servis entegrasyonu:**
11. **Bağlayıcı (connector) keşfi ve önerisi** — kullanıcının bağlayabileceği
    üçüncü parti servisleri (e-posta, takvim, proje yönetimi vb.) keşfedip
    öneren bir sistem — kullanıcının "istediği kadar hesap bağlama"
    hedefinin (bkz. Bölüm 1) somut bir uygulaması. Bir servis
    bağlandığında, model o servisin araçlarını (mesaj gönderme, görev
    oluşturma vb.) çağırabilir.
12. **Ek/deferred araç yükleme** — az kullanılan/uzmanlaşmış araçların
    başta yüklenmeyip, gerektiğinde aranıp devreye alındığı bir sistem
    (performans/karmaşıklık optimizasyonu — çok sayıda entegrasyon
    olduğunda hepsini baştan modele tanıtmak yerine, ihtiyaç anında
    getirme).
13. **Veri kaynağı araçları** — hava durumu, spor skorları, yer/mekan
    arama gibi belirli, yapılandırılmış veri kaynaklarına özel araçlar
    (genişleyen bir liste, MVP kapsamı dışında).

**Kullanıcı etkileşimi:**
14. **Kullanıcıya seçenekli soru sorma** — model bir tercih/onay
    gerektiğinde, serbest metin yerine tıklanabilir seçeneklerle kullanıcıya
    soru sorabilir (özellikle mobilde daha hızlı etkileşim).

> Not: "Düşünme/reasoning modu" ve "derin araştırma" bazı bakımlardan farklı
> kategorilerdir — reasoning modelin kendi iç süreci (bir "araç çağrısı"
> değil), derin araştırma ise gerçek bir araç (arama+sentezleme döngüsü
> çalıştıran bir fonksiyon). **3D model üretimi de bir araç değil, ayrı bir
> model türüdür** — tıpkı metin/görsel/ses üreten modeller gibi, kendi
> başına bir kategoridir (bkz. Bölüm 2, Mod 1 ve Mod 3).
>
> Referans: Bu liste, Claude'un (bu planlama sohbetinde kullanılan AI
> asistanının) kendi araç setinden ilham alınarak MarathonAI'nin bağlamına
> uyarlanmıştır. Sohbete özel UI bileşenleri (tarif kartı, gezi planı kartı
> gibi) MarathonAI'nin genel amaçlı doğasına uymadığı için listeye
> alınmamıştır; bunun yerine Design Modu'nun (madde 9) genel amaçlı görsel
> üretim yeteneği bu ihtiyacı karşılar.

---

## 7. Gizlilik ve Veri Saklama

- Sohbetler ve ayarlar **local-only**: kullanıcının kendi bilgisayarında
  saklanır, MarathonAI'nin herhangi bir sunucusuna gönderilmez.

---

## 8. Hukuki

- Uygulamaya bir **Kullanım Şartları / Sorumluluk Reddi (EULA benzeri)**
  metni eklenecek. Kapsaması gerekenler (taslak, nihai metin avukat
  onaylı olmalı):
  - Kullanıcının kendi AI hesaplarını kullanırken ilgili platformların kendi
    kullanım şartlarına uymaktan kullanıcının sorumlu olduğu.
  - Agent/Kontrol modunda AI'a verilen yetkilerin sonuçlarından (dosya
    değişikliği/silinmesi vb.) kullanıcının haberdar olması gerektiği.
  - Uygulamanın "olduğu gibi" sunulduğu, sorumluluk sınırlaması.
- Uygulama ismi ve "Alpha" etiketi ile başlangıçta riskli/deneysel olduğu
  açıkça belirtilecek.

---

## 9. Geliştirme Sıralaması (v1)

**Sıralama kararı (yazılıma geçiş aşamasında netleşti):**

1. **Önce Mod 1 (Resmi API)** — en az riskli, en standart entegrasyon
   (HTTP/JSON, otomasyon/DOM kırılganlığı yok). Önce uygulamanın genel
   arayüz temeli (pencere, sekme sistemi, tema, ayarlar) bu modla birlikte
   inşa edilir.
   - **İlk somut adım (kod yazımı burada başlıyor):** Basit bir pencere +
     tek bir AI sağlayıcısına (örn. OpenAI) API üzerinden bağlanıp mesaj
     gönderip cevap alabilme — küçük, çalışan bir iskelet. Bu çalıştıktan
     sonra tema, çoklu model desteği, sekme sistemi, ayarlar gibi katmanlar
     üzerine eklenecek. Büyük parçaları aynı anda inşa etmek yerine küçük,
     doğrulanabilir adımlarla ilerlenecek.
2. **Sonra Mod 3 (Local AI / HF)** — donanım/model yönetimi katmanı eklenir.
3. **En son Mod 2 (Web Arayüzü / CSS re-skin)** — en kırılgan/bakım
   gerektiren kısım; sağlam bir temel üzerine en zor parça en son eklenir.

> Not: Bölüm 2'deki mod açıklamaları (Mod 1/2/3'ün ne olduğu) hâlâ geçerli
> ve değişmedi — burada değişen sadece **hangisinin önce yazılacağı**,
> modların kendisi/özellikleri değil.

**Kontrol Modu (PC kontrolü) — geliştirme kapsamı dışında bırakıldı:**
Kontrol Modu (bilgisayarı AI'ya kontrol ettirme, bkz. Bölüm 6.3), ilk
yazılım aşamalarına *hiç karıştırılmayacak* — ne mimaride ne kodda bir yer
tutmayacak, tamamen ayrı, ileride ele alınacak bir gelecek fazı olarak
kalacak (GitHub sürümüne özel, bkz. Bölüm 10). Bu, temel mimarinin
"temiz" kalması ve PC kontrolü gibi yüksek riskli bir özelliğin erken
aşamada karmaşıklık/güvenlik yükü getirmemesi içindir.

### 9.1 MVP Kapsamı (tüm modlar tamamlandığında — "v1" olarak adlandırılan hedef)

- **Platform desteği (Mod 2 için):** ChatGPT + Gemini (sadece bu ikisi).
- **Çalışma modları:** Bölüm 9'daki sıraya göre inşa edilir — önce Mod 1
  (API), sonra Mod 3 (Local/HF), en son Mod 2 (Web/CSS re-skin). v1, üçü de
  tamamlandığında hazır sayılır.
- **Tasarım:** Siyah-beyaz, premium tema (Bölüm 10.1).
- **Referans (Mod 2 için):** AI-UX-Customizer projesi (selector haritalama +
  CSS enjeksiyon deseni).
- Diğer tüm gelişmiş özellikler (Agent modu, Kontrol modu, Design modu,
  Plan/Build, 3D üretim, vb.) MVP'nin **dışında** — ilk sürümden sonra,
  öncelik sırasına göre eklenecek. Kontrol Modu ayrıca Store sürümünde hiç
  yer almayacak (bkz. Bölüm 9 ve 10). ("İlk sürümlerden bu kadar şey
  eklemeyelim" kararı.)

---

## 10. Teknik Yapı Notları

- **Platform:** Windows masaüstü uygulaması.
- **Dil/Framework: C# (.NET) + WebView2.** (Karar tarihi: plan aşamasının
  sonu.) Sebep: WebView2'nin en olgun/resmi desteklenen SDK'sı C# için;
  JSON/HTTP/async işlemleri dilde yerleşik (ekstra kütüphane gerekmez);
  Windows'a native; GitHub Actions ile build/paketleme kolay. Saf C++
  alternatifi değerlendirildi ama bu kategoride (ağ isteği + JSON + GUI
  ağırlıklı masaüstü uygulaması) gereksiz yere ağır bulundu.
- **Gömülü tarayıcı motoru:** WebView2 (Microsoft Edge/Chromium tabanlı,
  Windows'a native, resmi SDK).
- **Build:** GitHub üzerinde (GitHub Actions ile CI/CD düşünülebilir,
  detaylandırılmadı).
- **Referans mimari (AI-UX-Customizer'dan uyarlanacak):**
  - Platform tespiti: hostname'e göre (`chatgpt.com` / `gemini.google.com`).
  - Her platform için merkezi bir `SELECTORS` haritası (input kutusu, gönder
    alanı, mesaj balonları, avatar, sidebar, canvas/design alanı, vb.).
  - Ortak bir CSS/tema motoru — selector'lar platforma göre değişir, enjeksiyon
    mantığı ortak kalır.
  - Sayfa yüklenirken erken müdahale (`document-start` benzeri an, WebView2'de
    `NavigationCompleted` veya `AddScriptToExecuteOnDocumentCreated`).
- **Bilinen risk — bakım yükü:** Referans proje 2 platform için bile 21.700+
  satır kod gerektirmiş ve sık güncellenmesi gerekiyor (siteler arayüzlerini
  değiştirdikçe selector'lar bozulabilir). Öneri: bir "kırılma izleme"
  mekanizması (selector'lar bulunamazsa kullanıcıya zarif bir uyarı gösterme)
  düşünülmeli — bu MVP sonrası netleştirilecek.
- **Profil/oturum izolasyonu:** Chrome'un "kişiler" (profiles) sistemi gibi;
  kullanıcı aynı platform için birden fazla hesap/profil ekleyebilir, her
  biri izole cookie/session alanında çalışır.

### 10.1 Tasarım Sistemi — Renk ve Tipografi

- **Renk paleti:** Tam siyah-beyaz. Gri tonlar kullanılmaz, keskin kontrast
  hedeflenir (minimalist, premium his).
  - **Koyu tema:** Arka plan siyah, yazılar/metin beyaz.
  - **Açık tema:** Arka plan beyaz, yazılar/metin siyah.
  - Kullanıcı ayarlardan koyu/açık tema arasında seçim yapabilecek (ikisi de
    desteklenecek, tek bir sabit tema değil).
- **Font ailesi: Space Grotesk** (Google Fonts üzerinden ücretsiz, açık
  lisanslı, ticari kullanıma uygun).
  - **Büyük fontlar (başlıklar):** Extra Bold / Black İtalik kesimi —
    yoğun, iddialı, geniş harf aralıklı ("COLUMBIA" tarzı referans örnek).
  - **Orta büyüklükteki fontlar:** Regular ağırlık, büyük harf (uppercase)
    + geniş letter-spacing ("LOW EARTH ORBITAL SPACECRAFT" tarzı referans
    örnek).
  - **Küçük fontlar (gövde metni, buton yazıları vb.):** Regular ağırlık,
    normal harf (uppercase zorunlu değil).

---

- **"Bilinmeyen Yayıncı" (SmartScreen) sorunu ve çözüm yolları:**
  - Windows, imzasız `.exe` dosyalarında "Bilinmeyen Yayıncı" uyarısı gösterir.
  - **2024-2026 arası önemli değişiklik:** EV (Extended Validation) sertifikaların
    "anında SmartScreen güvenini kazandırma" özelliği Microsoft tarafından
    kaldırıldı — artık standart ve EV sertifikalar itibar kazanma konusunda
    aynı şekilde çalışıyor, ikisi de zamana yayılı itibar biriktirmesi
    gerektiriyor.
  - **Tamamen ücretsiz, güvenilir bir sertifika yolu yok** (piyasada böyle
    iddia eden servisler güvenilir değil) — Store dışı dağıtımda.
  - **Karar: Microsoft Store üzerinden MSIX paketi olarak dağıtım.** Bu
    tamamen ücretsiz bir çözüm:
    - Geliştirici hesabı kaydı **ücretsiz** (2026 itibarıyla hem bireysel
      hem şirket hesabı için — Microsoft, Mayıs 2026'da şirket hesap
      ücretini de kaldırdı, bireysel hesaplar 2025 sonundan beri
      ücretsizdi).
    - Kod imzalama **otomatik ve ücretsiz** — Microsoft, Store'a
      yüklenen MSIX paketini kendisi imzalıyor, ayrıca sertifika almaya
      gerek yok.
    - Kullanıcı hiçbir SmartScreen "Bilinmeyen Yayıncı" uyarısı görmüyor.
  - Alternatif (Store dışı dağıtım isteniyorsa, ücretli): Microsoft'un
    "Artifact Signing" servisi (aylık ~10$'dan başlıyor).
  - **Sonuç: Store dağıtımı, hem ücretsiz hem de SmartScreen sorununu
    kökünden çözen yöntem — önerilen ve kararlaştırılan yol budur.**
  - **Kabul riski (açık soru, dikkatli yaklaşılmalı):** Microsoft'un genel
    yönü, AI ajanlarını "güvenli, politika-yönetimli bir platform" içinde
    desteklemek yönünde (2026 itibarıyla Microsoft Execution Containers,
    Agent 365 gibi girişimlerle) — yani "AI ajanı = otomatik red" değil.
    Ama MarathonAI'nin bazı özellikleri (Kontrol Modu'nun bilgisayar
    kontrolü, geniş dosya sistemi erişimi, kod çalıştırma) Store'un
    inceleme sürecinde ekstra dikkat gerektirecektir. Net "kabul
    edilir/edilmez" kesin değil — gerçek submission anında netleşir. Risk
    azaltma stratejisi:
    - MVP'de (Mod 2, sadece web re-skin) bu riskli özellikler zaten yok —
      ilk sürüm görece "sorunsuz" bir Store başvurusu olur.
    - Kontrol Modu / geniş sistem erişimi gibi özellikler eklenirken,
      kullanıcı izni/onay akışlarının Store politikalarına (şeffaflık,
      kullanıcı kontrolü, veri gizliliği) açıkça uygun tasarlanması gerekir.
    - Gerekirse, riskli özellikler Store dışı bir "genişletilmiş sürüm"
      olarak da sunulabilir (ayrı dağıtım kanalı, ücretli imzalama ile).
  - **Karar: İki ayrı dağıtım kanalı.**
    - **Microsoft Store sürümü:** Store politikalarına uygun, "güvenli"
      özellik seti — Kontrol Modu (bilgisayar kontrolü) gibi riskli/güçlü
      yetkiler **bu sürümde yer almaz.**
    - **GitHub sürümü:** Tam özellikli sürüm — Kontrol Modu dahil tüm
      gelişmiş modlar burada bulunur. Bu sürüm Store dışı dağıtılır (kod
      imzalama için ücretli servis gerekebilir, ya da kullanıcı
      "Bilinmeyen Yayıncı" uyarısını kabul ederek kurar — GitHub'dan
      indiren kullanıcı kitlesi bu konuda daha bilinçli/toleranslı kabul
      edilir).
    - Bu ayrım, birçok geliştirici aracının izlediği "Store'da sade/lite
      sürüm, GitHub'da tam/güçlü sürüm" modeline benzer.

### 10.2 Logo

Logo, ok/imleç (cursor) formunda soyut bir simge — aynı zamanda "A" harfini
çağrıştırıyor (MarathonAI'nin son harfi). İki iç içe geçmiş ok/üçgen
formundan oluşuyor: biri içi boş/çerçeve (kontur), diğeri dolu (üstte,
hafif kaydırılmış) — hareket/hız hissi veriyor. Yazısız, sade simge olarak
kullanılacak; marka adı ayrı yerlerde metin (Space Grotesk) ile
kullanılır.

- **Renk:** Koyu temada siyah zemin üzerine beyaz simge; açık temada
  tersine çevrilir (beyaz zemin üzerine siyah simge) — Bölüm 10.1'deki tema
  sistemiyle tutarlı.
- **Kullanım:** Uygulama ikonu, başlık çubuğu, açılış ekranı gibi yerlerde
  yazısız/tek başına kullanılacak.

---

## 11. Araştırma Kaynakları / Ekler

- `marathonai_research_notes.md` — AI-UX-Customizer projesinin detaylı
  mimari analizi (selector kategorileri, CSS enjeksiyon deseni, riskler).
- `marathonai_dom_inventory.py` — (kullanılmadı, alternatif manuel DevTools
  yöntemi tercih edildi) Playwright tabanlı DOM envanter aracı; kullanıcı
  kendi eliyle giriş yapar, script sadece sayfa yapısını okur, otomatik
  login yapmaz.
- Manuel DOM inceleme yöntemi (tercih edilen): Chrome DevTools →
  sağ tık → Denetle → Copy element, her önemli element için tek tek.

---

## 12. Açık Sorular / Sonraki Adımlar

- [ ] ChatGPT ve Gemini için DOM envanterini (input kutusu, gönder butonu,
      mesaj alanı, vb. selector'ları) manuel olarak çıkarmak.
- [ ] Bu envanterden yola çıkarak `SELECTORS` haritasını oluşturmak.
- [ ] WebView2 tabanlı temel uygulama iskeletini kurmak (sekme yönetimi,
      profil izolasyonu).
- [ ] CSS/JS enjeksiyon motorunu (tema sistemi) inşa etmek.
- [ ] "Kırılma izleme" mekanizmasının tasarımı.
- [ ] Kullanım Şartları / Sorumluluk Reddi metninin taslağının hazırlanması.
- [ ] Sonraki fazlar için detaylı yol haritası (Mod 1, Mod 3, Agent modu,
      Kontrol modu, vb. hangi sırayla eklenecek).
- [x] Dağıtım yöntemi kararı: **Microsoft Store (MSIX)** — ücretsiz geliştirici
      hesabı + Microsoft'un otomatik/ücretsiz kod imzalaması sayesinde hem
      maliyetsiz hem de "Bilinmeyen Yayıncı" (SmartScreen) sorununu kökünden
      çözüyor (bkz. Bölüm 10).

---

*Bu doküman, planlama sohbeti ilerledikçe güncellenmeye devam edecek.*
