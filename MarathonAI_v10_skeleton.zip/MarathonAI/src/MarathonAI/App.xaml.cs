using System.Windows;
using MarathonAI.Core.Settings;

namespace MarathonAI;

/// <summary>
/// Uygulamanın giriş noktası. Başlangıçta kaydedilmiş tema tercihini
/// (koyu/açık) yükleyip uygular (bkz. ThemeManager, Bölüm 5 ve 10.1).
/// </summary>
public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        var savedTheme = ThemeManager.LoadSavedTheme();
        ThemeManager.Apply(savedTheme);
    }
}
