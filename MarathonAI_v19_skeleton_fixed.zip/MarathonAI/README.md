# MarathonAI

> Durum: **Alpha / Aktif geliştirme (iskelet aşaması).**

Çoklu AI entegrasyon masaüstü uygulaması (Windows). Detaylı plan için
`docs/MarathonAI_Plan.md` dosyasına bakın.

## Klasör Yapısı

```
MarathonAI/
├── src/
│   └── MarathonAI/          # .NET 8 / WPF proje kökü
│       ├── MarathonAI.csproj
│       ├── App.xaml(.cs)     # Uygulama giriş noktası
│       ├── MainWindow.xaml(.cs)      # Ana pencere: sekme sistemi (TabControl)
│       ├── SettingsWindow.xaml(.cs)  # Ayarlar penceresi: API anahtarı girişleri
│       ├── UI/
│       │   ├── ChatTab.cs                   # Tek bir sekmenin durumu (mesajlar + sağlayıcı)
│       │   ├── ChatMessage.cs               # Paylaşılan mesaj tipi (MessageRole enum dahil)
│       │   ├── BoolToAlignmentConverter.cs  # Mesaj hizalaması (kullanıcı sağ, model sol)
│       │   └── VisibilityConverters.cs      # Boş durum (empty state) görünürlük converter'ları
│       ├── Themes/
│       │   ├── Styles.xaml       # Tasarım sistemi: tipografi + tüm kontrol şablonları
│       │   ├── Colors.Dark.xaml  # Koyu tema renkleri (siyah zemin, beyaz yazı)
│       │   └── Colors.Light.xaml # Açık tema renkleri (beyaz zemin, siyah yazı)
│       ├── Assets/
│       │   └── Fonts/            # Space Grotesk (.ttf, SIL Open Font License)
│       ├── Resources/
│       │   └── Lang/
│       │       ├── tr.json       # Türkçe çeviriler
│       │       └── en.json       # İngilizce çeviriler
│       └── Core/
│           ├── Api/
│           │   ├── IChatClient.cs                # Sağlayıcı-bağımsız arayüz (streaming)
│           │   ├── ApiChatMessage.cs             # API'ye giden mesaj tipi (user/assistant)
│           │   ├── OpenAiCompatibleChatClient.cs # Ortak temel sınıf (OpenAI SSE streaming formatı)
│           │   ├── OpenAiChatClient.cs           # OpenAI implementasyonu
│           │   ├── GroqChatClient.cs             # Groq implementasyonu (ücretsiz tier)
│           │   ├── MistralChatClient.cs          # Mistral implementasyonu
│           │   ├── ProviderRegistry.cs           # Sağlayıcı listesi/seçim sistemi
│           │   └── ApiKeyStore.cs                # Ayarlardan/ortam değişkeninden key okuma
│           ├── Localization/
│           │   └── LocalizationManager.cs  # JSON tabanlı çalışma zamanı dil sistemi
│           ├── Tools/
│           │   ├── ToolTypes.cs         # Araç tanımı, çağrı isteği/sonucu tipleri
│           │   ├── ToolRegistry.cs      # Kullanılabilir araçların merkezi listesi
│           │   ├── ReadFileTool.cs      # İlk gerçek araç: dosya okuma (FileSystemGuard kullanır)
│           │   ├── WebSearchTool.cs     # İkinci araç: web araştırma (Tavily API)
│           │   ├── DeepResearchTool.cs  # Üçüncü araç: paralel çoklu-arama + sentez
│           │   └── ToolCallingLoop.cs   # Model↔araç çağrı/sonuç döngüsü orkestratörü
│           └── Settings/
│               ├── AppSettings.cs      # Ayar veri modeli (API key'ler + tema + dil + dosya erişimi)
│               ├── SettingsManager.cs  # Diske kaydetme/yükleme (%AppData%)
│               ├── SecureStore.cs      # DPAPI ile API key şifreleme/çözme
│               ├── ThemeManager.cs     # Çalışma zamanı koyu/açık tema geçişi
│               └── FileSystemGuard.cs  # Dosya erişim politika kontrolcüsü (henüz bağlanmadı)
├── docs/             # Plan ve araştırma dokümanları
├── scripts/          # Yardımcı scriptler (DOM inceleme aracı, kullanılmadı)
└── .github/workflows/  # GitHub Actions CI/CD (build.yml)
```

İleride eklenecek klasörler (henüz yok): `Core/Agent` (Mod 1 agent mantığı),
`Core/LocalModels` (Mod 3), `Platforms/` (Mod 2 site adaptörleri — en son
faz).

## Geliştirme Durumu

**Şu an: On dokuzuncu kod iskeleti tamamlandı (Adım 19) — kullanıcı
tasarımı entegre edildi.**

**Proje ilerlemesi: ~%34**

Kullanıcının hazırladığı HTML prototip (`marathonai-ui-prototype.html`)
WPF'e dönüştürüldü ve entegre edildi. Büyük değişiklikler:

- **Sol kenar panel (sidebar)** eklendi: logo, "Önceki sohbetler"
  listesi (gerçek `Tabs` koleksiyonundan türetiliyor, sahte veri değil),
  "+ Yeni Sohbet" butonu, alt kısımda Ayarlar butonu + sürüm etiketi.
- **Sekme kapatma** eklendi — her sekme başlığının yanında bir "×"
  butonu var, en az 1 sekme her zaman açık kalıyor (son sekme
  kapatılamıyor).
- **Boş durum (empty state)** eklendi — bir sekmede hiç mesaj yokken
  ortada "M." işareti + "Bir şeyler yazarak başlayın" ipucu görünüyor.
- **Composer yeniden tasarlandı** — çok satırlı metin alanı (gerçek
  placeholder metniyle), altında sol tarafta klavye kısayolu ipucu
  ("ENTER ile gönder · SHIFT+ENTER ile yeni satır"), sağ tarafta
  Araçlar anahtarı + model seçici + gönder butonu. Shift+Enter artık
  yeni satır ekliyor, sadece Enter gönderiyor.
- Sekme çubuğu artık görsel olarak özel bir `ItemsControl` ile çiziliyor
  (× butonu barındırabilmek için), `TabControl`'ün kendisi sadece
  "hangi içerik gösterilecek" mantığı için arka planda kullanılıyor.

Tüm yeni kontroller (`ContentPresenter` kullanan her `ControlTemplate`)
`TextElement.Foreground` mirasını doğru şekilde içeriyor — Adım 12'de
düzeltilen kritik render hatası bu tasarımda tekrarlanmadı (elle
doğrulandı, 11 `ContentPresenter`'ın hepsi kontrol edildi).

Henüz: kod çalıştırma aracı (yarım kaldı, `Core/Tools/CodeExecution/`
altında iskelet var), gerçek mikrofon/ses ikonları (prototipte SVG
olarak vardı, henüz eklenmedi), Mod 2/Mod 3, 26 dilin tamamı YOK.

### Nasıl Derlenir

Bu proje **Windows + .NET 8 SDK** gerektirir (WPF + WebView2 kullanıyor).
Linux/Mac üzerinde derlenemez.

**GitHub Actions ile (önerilen):** `main` dalına push yapıldığında
`.github/workflows/build.yml` otomatik olarak Windows runner'da derler,
derleme çıktısını "Actions" sekmesinden indirebilirsiniz.

**Kendi bilgisayarınızda (Windows + Visual Studio):**
1. [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0) kurun.
2. `src/MarathonAI/MarathonAI.csproj` dosyasını Visual Studio ile açın.
3. F5 ile çalıştırın.
4. Pencerenin sağ üstündeki **"AYARLAR"** butonuna tıklayıp:
   - **Dil** — Türkçe/English arasında seçim yapın (anında uygulanır).
   - **Tema** — Koyu/Açık arasında seçim yapın (anında uygulanır).
   - **API Anahtarı** — En az bir sağlayıcı için anahtar girin (diskte
     şifrelenmiş olarak saklanır):
     - **Groq** — [console.groq.com](https://console.groq.com) üzerinden
       **ücretsiz** hesap açıp alabilirsiniz. Varsayılan sağlayıcı budur.
     - **OpenAI** — kendi OpenAI API anahtarınız (varsa).
     - **Mistral** — kendi Mistral API anahtarınız (varsa,
       [console.mistral.ai](https://console.mistral.ai) üzerinden).
     - **Tavily (Web Araştırma)** — "Araçlar" anahtarını açtığınız
       sekmelerde web araması yapabilmek için gerekli, **ücretsiz**
       hesap [tavily.com](https://tavily.com) üzerinden alınabilir
       (kart bilgisi istemiyor).
5. "+ Yeni Sekme" ile birden fazla bağımsız sohbet açabilir, her
   sekmenin sağ üstündeki menüden o sekmeye özel sağlayıcı seçebilir,
   sohbet devam ederken modeli değiştirebilirsiniz — konuşma geçmişi
   korunur, cevaplar akarak gelir. Sekmenin **"Araçlar"** anahtarını
   açarsanız, model dosya okuma ve web araması yapabilir (ilgili API
   anahtarları girilmiş ve dosya erişimi izinliyse).

(Alternatif/geliştirme amaçlı: `MARATHONAI_GROQ_KEY` / `MARATHONAI_OPENAI_KEY`
ortam değişkenleri de hâlâ çalışıyor, ayarlar panelinde bir key yoksa
buraya bakılıyor.)

Detaylar için `docs/MarathonAI_Plan.md` — Bölüm 9 (Geliştirme Sıralaması).
