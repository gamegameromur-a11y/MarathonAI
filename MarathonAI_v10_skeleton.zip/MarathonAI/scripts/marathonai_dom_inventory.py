"""
MarathonAI - DOM Envanter Aracı
=================================
Bu script, hedef AI sitelerine (ChatGPT, Claude, Gemini, GLM, Mistral) gerçek bir
tarayıcı penceresinde (headful) bağlanır. Giriş işlemini SEN kendi elinle yaparsın —
script hiçbir zaman kullanıcı adı/şifreni görmez, tutmaz ya da otomatik girmez.

Sen giriş yapıp sohbet ekranına ulaştıktan sonra terminalde Enter'a basarsın,
script o anki sayfa yapısını (input kutusu, gönder butonu, mesaj alanı adayları)
tarayıp bir JSON rapor + ekran görüntüsü üretir. Bu rapor, her site için CSS/JS
"adaptör" yazarken referans olarak kullanılır.

KURULUM (senin bilgisayarında, bir kere):
    pip install playwright
    playwright install chromium

ÇALIŞTIRMA:
    python marathonai_dom_inventory.py

ÇIKTI:
    ./dom_reports/<site_adi>_report.json   -> element envanteri
    ./dom_reports/<site_adi>_screenshot.png -> o anki ekran görüntüsü
"""

import json
import os
import time
from pathlib import Path
from playwright.sync_api import sync_playwright

# Hedef siteler - istersen ekleyip çıkarabilirsin
SITES = [
    {"name": "chatgpt", "url": "https://chat.openai.com/"},
    {"name": "claude", "url": "https://claude.ai/new"},
    {"name": "gemini", "url": "https://gemini.google.com/app"},
    {"name": "glm", "url": "https://chat.z.ai/"},          # GLM'in resmi chat arayüzü değişebilir, kontrol et
    {"name": "mistral", "url": "https://chat.mistral.ai/chat"},
]

OUTPUT_DIR = Path("./dom_reports")

# Envanterde arayacağımız olası element tipleri ve bulmak için kullanılan
# genel (siteye özel olmayan) sezgisel seçiciler. Bunlar KESIN doğru sonuç
# vermez -- amaç "aday listesi" çıkarmak, adaptör yazarken sen/ben bunları
# elle doğrulayıp seçeriz.
CANDIDATE_SELECTORS = {
    "text_input_candidates": [
        "textarea",
        "div[contenteditable='true']",
        "[role='textbox']",
        "input[type='text']",
    ],
    "send_button_candidates": [
        "button[type='submit']",
        "button[aria-label*='Send' i]",
        "button[aria-label*='Gönder' i]",
        "button[data-testid*='send' i]",
    ],
    "message_container_candidates": [
        "[data-message-author-role]",
        "[class*='message' i]",
        "[class*='chat-turn' i]",
        "article",
    ],
    "new_chat_candidates": [
        "a[href*='new' i]",
        "button[aria-label*='New chat' i]",
        "button[aria-label*='Yeni sohbet' i]",
    ],
    "file_upload_candidates": [
        "input[type='file']",
        "button[aria-label*='attach' i]",
        "button[aria-label*='upload' i]",
    ],
}


def describe_element(handle):
    """Bir element handle'ından envanter için güvenli/kullanışlı bilgi çıkarır."""
    try:
        return handle.evaluate(
            """(el) => {
                const rect = el.getBoundingClientRect();
                return {
                    tag: el.tagName.toLowerCase(),
                    id: el.id || null,
                    class_list: Array.from(el.classList || []),
                    aria_label: el.getAttribute('aria-label'),
                    role: el.getAttribute('role'),
                    data_testid: el.getAttribute('data-testid'),
                    placeholder: el.getAttribute('placeholder'),
                    contenteditable: el.getAttribute('contenteditable'),
                    visible: !!(rect.width && rect.height) &&
                             getComputedStyle(el).visibility !== 'hidden' &&
                             getComputedStyle(el).display !== 'none',
                    bounding_box: {
                        x: rect.x, y: rect.y,
                        width: rect.width, height: rect.height
                    },
                    outer_html_snippet: el.outerHTML.slice(0, 300)
                };
            }"""
        )
    except Exception as e:
        return {"error": str(e)}


def scan_page(page, max_per_selector=5):
    """Sayfadaki aday elementleri CANDIDATE_SELECTORS'a göre tarar."""
    report = {}
    for category, selectors in CANDIDATE_SELECTORS.items():
        report[category] = []
        for selector in selectors:
            try:
                elements = page.query_selector_all(selector)
            except Exception as e:
                report[category].append({"selector": selector, "error": str(e)})
                continue

            found = 0
            for el in elements:
                if found >= max_per_selector:
                    break
                info = describe_element(el)
                if info.get("visible"):  # sadece görünür olanları raporla
                    info["matched_selector"] = selector
                    report[category].append(info)
                    found += 1
    return report


def run():
    OUTPUT_DIR.mkdir(exist_ok=True)

    with sync_playwright() as p:
        # headless=False -> gerçek, görünür pencere. Sen buradan giriş yapacaksın.
        browser = p.chromium.launch(headless=False)

        for site in SITES:
            print(f"\n{'='*60}")
            print(f"Site: {site['name']}  ({site['url']})")
            print(f"{'='*60}")

            context = browser.new_context()  # her site için izole profil/oturum
            page = context.new_page()
            page.goto(site["url"], wait_until="domcontentloaded")

            input(
                f"\n[{site['name']}] Tarayıcıda açılan sayfada KENDİ ELİNLE giriş yap "
                f"ve sohbet ekranına ulaş.\n"
                f"Hazır olduğunda buraya dönüp ENTER'a bas..."
            )

            # Kullanıcı hazır dedikten sonra biraz bekle, sayfa otursun
            time.sleep(2)

            print(f"[{site['name']}] Sayfa taranıyor...")
            report = scan_page(page)

            # Rapor + ekran görüntüsü kaydet
            report_path = OUTPUT_DIR / f"{site['name']}_report.json"
            screenshot_path = OUTPUT_DIR / f"{site['name']}_screenshot.png"

            with open(report_path, "w", encoding="utf-8") as f:
                json.dump(report, f, ensure_ascii=False, indent=2)

            page.screenshot(path=str(screenshot_path), full_page=False)

            print(f"[{site['name']}] Rapor kaydedildi -> {report_path}")
            print(f"[{site['name']}] Ekran görüntüsü kaydedildi -> {screenshot_path}")

            context.close()

        browser.close()

    print(f"\nTüm siteler tarandı. Raporlar '{OUTPUT_DIR}/' klasöründe.")
    print("Not: Bu raporlar 'aday' listeleridir, kesin sonuç değildir.")
    print("Her site için doğru elementi seçmek üzere raporu + ekran görüntüsünü birlikte inceleyeceğiz.")


if __name__ == "__main__":
    run()
