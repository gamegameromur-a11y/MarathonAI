using System.Diagnostics;
using System.Text;

using MarathonAI.Core.Tools;

namespace MarathonAI.Core.Tools.CodeExecution;

/// <summary>
/// Tüm ICodeRunner implementasyonlarının kullandığı ortak süreç
/// çalıştırma mantığı. Zaman aşımı, stdout/stderr yakalama ve process
/// öldürme mantığı burada TEK YERDE tutuluyor — her dil çalıştırıcısı
/// (PythonRunner, CppRunner, RustRunner) bu güvenlik davranışını miras
/// alıyor, her biri kendi kendine ayrı ayrı (ve potansiyel olarak
/// tutarsız) bir timeout mantığı yazmıyor.
///
/// GÜVENLİK NOTU (bkz. docs/MarathonAI_Plan.md, Bölüm 6.3 — "model
/// kendi kendini sınırlar" varsayımına güvenilmeyeceği prensibi): Bu
/// sınıf sadece zaman aşımı sağlıyor, TAM bir sandbox (dosya sistemi
/// izolasyonu, ağ erişimi engelleme, kaynak kotası) DEĞİL. Gerçek bir
/// güvenlik sınırı için ileride Windows Sandbox, bir konteyner (Docker)
/// veya AppContainer gibi bir izolasyon katmanına taşınması gerekir —
/// bu, açık bir sonraki adım olarak not edildi (bkz. README.md).
/// </summary>
internal static class ProcessRunner
{
    public static async Task<CodeExecutionResult> RunProcessAsync(
        string fileName,
        string arguments,
        string? workingDirectory,
        TimeSpan timeout,
        CancellationToken cancellationToken)
    {
        var startInfo = new ProcessStartInfo
        {
            FileName = fileName,
            Arguments = arguments,
            WorkingDirectory = workingDirectory,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true
        };

        using var process = new Process { StartInfo = startInfo };
        var stdout = new StringBuilder();
        var stderr = new StringBuilder();

        process.OutputDataReceived += (_, e) => { if (e.Data != null) stdout.AppendLine(e.Data); };
        process.ErrorDataReceived += (_, e) => { if (e.Data != null) stderr.AppendLine(e.Data); };

        try
        {
            process.Start();
            process.BeginOutputReadLine();
            process.BeginErrorReadLine();

            using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            timeoutCts.CancelAfter(timeout);

            try
            {
                await process.WaitForExitAsync(timeoutCts.Token);
            }
            catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
            {
                // Zaman aşımı (kullanıcı iptali değil) — süreci zorla
                // sonlandır. Bu, sonsuz döngüye giren veya çok uzun süren
                // kodun uygulamayı kilitlememesini garanti eden temel
                // güvenlik sınırı.
                TryKill(process);
                return new CodeExecutionResult(
                    Success: false,
                    StandardOutput: stdout.ToString(),
                    StandardError: stderr.ToString(),
                    ExitCode: null,
                    TimedOut: true);
            }

            return new CodeExecutionResult(
                Success: process.ExitCode == 0,
                StandardOutput: stdout.ToString(),
                StandardError: stderr.ToString(),
                ExitCode: process.ExitCode,
                TimedOut: false);
        }
        catch (Exception ex)
        {
            // Örn. dil çalışma zamanı (python.exe, g++.exe, cargo.exe)
            // kullanıcının bilgisayarında kurulu değilse buraya düşer.
            return new CodeExecutionResult(
                Success: false,
                StandardOutput: string.Empty,
                StandardError: $"Süreç başlatılamadı: {ex.Message}",
                ExitCode: null,
                TimedOut: false);
        }
    }

    private static void TryKill(Process process)
    {
        try
        {
            if (!process.HasExited)
            {
                process.Kill(entireProcessTree: true);
            }
        }
        catch (Exception)
        {
            // Süreç zaten kendiliğinden sonlanmış olabilir — güvenli
            // şekilde yoksay.
        }
    }
}
