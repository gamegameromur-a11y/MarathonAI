using System.Linq;
using MarathonAI.Core.Api;

namespace MarathonAI.Core.Tools;

/// <summary>
/// Model bir aracı çağırmak istediğinde, aracı gerçekten çalıştırıp
/// sonucu tekrar modele gönderen ve model nihai bir metin cevabı
/// verene kadar bu döngüyü tekrarlayan orkestratör (bkz.
/// docs/MarathonAI_Plan.md, Bölüm 6.6).
///
/// Akış:
///   1. Konuşma geçmişi + kullanılabilir araçlar API'ye gönderilir.
///   2. Model "tool_calls" ile cevap verirse: her çağrı için
///      ToolRegistry'den handler bulunur, ExecuteAsync çağrılır
///      (FileSystemGuard gibi güvenlik kontrolleri handler'ın
///      İÇİNDE yapılır, bkz. ReadFileTool.cs).
///   3. Araç sonuçları "tool" rolünde konuşma geçmişine eklenir,
///      adım 1'e dönülür.
///   4. Model normal bir metin cevabı verdiğinde döngü biter.
///
/// Sonsuz döngü riskine karşı MaxTurns ile bir üst sınır konuyor.
/// </summary>
public sealed class ToolCallingLoop
{
    private const int MaxTurns = 8;

    public async Task<string> RunAsync(
        IChatClient chatClient,
        List<ApiChatMessage> conversationHistory,
        CancellationToken cancellationToken = default)
    {
        var availableTools = ToolRegistry.All.Select(t => t.Definition).ToList();

        for (var turn = 0; turn < MaxTurns; turn++)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var result = await chatClient.SendMessageWithToolsAsync(
                conversationHistory, availableTools, cancellationToken);

            if (result.ToolCalls.Count == 0)
            {
                return result.TextResponse ?? string.Empty;
            }

            // Modelin araç çağırma isteğini, kendi "assistant" mesajı
            // olarak geçmişe ekliyoruz — API'ler bir sonraki turda bu
            // mesajı görmek zorunda, aksi halde "tool" mesajının hangi
            // çağrıya cevap verdiği anlamsız kalır.
            conversationHistory.Add(ApiChatMessage.AssistantWithToolCalls(result.ToolCalls));

            foreach (var toolCall in result.ToolCalls)
            {
                var handler = ToolRegistry.FindByName(toolCall.ToolName);

                var resultJson = handler is null
                    ? $$"""{"success": false, "error": "Bilinmeyen araç: {{toolCall.ToolName}}"}"""
                    : await handler.ExecuteAsync(toolCall.ArgumentsJson, cancellationToken);

                conversationHistory.Add(ApiChatMessage.ToolResult(toolCall.Id, resultJson));
            }
        }

        return "MarathonAI: Araç kullanımı çok uzun sürdü (izin verilen tur sayısı aşıldı), işlem durduruldu.";
    }
}
