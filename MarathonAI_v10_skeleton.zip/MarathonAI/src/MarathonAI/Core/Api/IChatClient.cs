namespace MarathonAI.Core.Api;

/// <summary>
/// Tüm Mod 1 (Resmi API) sağlayıcılarının uyacağı ortak arayüz.
/// OpenAI, Claude, Gemini, Mistral vb. her biri bu arayüzü kendi
/// implementasyonuyla karşılar — böylece MainWindow (ve sekme/model
/// seçim sistemi) hangi sağlayıcıyla konuştuğunu bilmek zorunda kalmaz,
/// sadece IChatClient ile çalışır.
///
/// StreamMessageAsync, cevabı parça parça (token/chunk) döndürür —
/// kullanıcı arayüzde cevabın "akarak" oluştuğunu görür (bkz.
/// docs/MarathonAI_Plan.md, Bölüm 1 — "hız" marka değeri). Tüm konuşma
/// geçmişini (conversationHistory) kabul eder, tek bir mesaj değil —
/// böylece model önceki mesajları "hatırlayarak" cevap verir.
///
/// İleride bu arayüze şunlar eklenecek:
///   - Tool-calling (Bölüm 6.6 — MarathonAI Araç Kütüphanesi)
///   - System prompt / reasoning effort parametreleri (Bölüm 4)
/// </summary>
public interface IChatClient
{
    IAsyncEnumerable<string> StreamMessageAsync(
        IReadOnlyList<ApiChatMessage> conversationHistory,
        CancellationToken cancellationToken = default);
}
